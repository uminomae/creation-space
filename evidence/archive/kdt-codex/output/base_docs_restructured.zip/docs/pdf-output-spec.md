# 出力仕様書

**バージョン**: 2.3  
**作成日**: 2026-02-09  
**位置づけ**: 3層アーキテクチャ「変換層」の仕様書  
**配置先**: `docs/pdf-output-spec.md`  
**前版からの変更**: v2.2で§5と reader-rulesの関係を明示。ドラフトメタ情報ルール追加。internal版フロー明記。PDF出力フロー統合。

---

## 0. 本仕様の前提——なぜ「論文」ではなく「読み物」か

> 読み物はみんな一人の意見じゃない？（S28）
> 休憩所のたわいもない対話のように、誰かの創造性に貢献すると思って作ってるんだ。（S29）
> SaaSのようなもの。残す文章ではない。（S27）

本仕様の出力は**ビジネス啓発系の読み物**である。

| v1.0の前提（廃止） | v2.0の前提 | 根拠 |
|-------------------|-----------|------|
| 論文 | 読み物 | S28 |
| 完成版のスナップショット | SaaS型。常に最新の作成中を公開 | S27 |
| 学術的な証明 | 足場・たとえとしての構造類似 | S04, S28 |
| 上から下への知識伝達 | 休憩所の対等な気づきの共有 | S29 |
| 読者に正解を教える | 読者の創造性のヒントになる | S29 |

**声の基準**: `base/voice/pjdhiro-values-base.md` を参照。
pjdhiroは研究者ではなく探究者、ビジネス啓発系作家、スモールビジネスの忍者（S31）。

---

## 1. 出力の性格

### 1.1 全てが仮説

出力される読み物は全て「仮説の塊」（S28）。章ごとに確信度が異なってよい:

| 温度 | 表現例 | 使いどころ |
|------|--------|-----------| 
| 確定 | 「〜である」 | コア定義（D1-D4）、十分に練られた構造 |
| ひらめき | 「〜のように見える」「〜と思う」 | 構造類似の指摘、探索中の発見 |
| もしかして | 「〜かもしれない」「まだわからないが」 | 仮説保持中の論点、保持論点（ISS） |

### 1.2 構造類似の扱い

学術的知見は**証明ではなく足場**として使う（S04, S28）:

> BIONの理論にこうある。本論との類似性はこう。（S04）

つまり:
- ✗ 「Bionの理論がこれを証明している」
- ✓ 「Bionがcontainerと呼んだものと、ここで言うWithholdは、同じ方向を指している」
- ✓ 「世阿弥の『秘すれば花』も同じ構造——見せないことで保持する」

群盲象チェック（TC-004）の精神: 複数の領域から同じ構造を指し示すことで、像が浮かび上がる。

### 1.3 SaaS型ビルド

出力は「完成品のスナップショット」ではなく、**生きているコンテンツの現時点版**:

- ビルドごとに内容が変わって当然
- 読者には「作成中」であることが前提として伝わる
- 版番号ではなくビルド日時で管理
- 保持論点（ISS）が残っていることは品質問題ではなく創造性の指標

---

## 2. 出力種別

### 2.1 一覧

| # | 種別 | 読者 | エンジン | トーン | 公開 |
|---|------|------|---------|--------|------|
| 0 | pjdhiro | 著者自身（私用） | pandoc/lualatex | 内省的。著者の声そのまま | ✗ |
| 1 | general | 創造に悩む一般読者 | pandoc/lualatex | 対話的。日常語。です・ます | ✓ |
| 2 | designer | プロジェクト設計者・経営者 | pandoc/lualatex | 実践的。フレームワーク提示 | ✓ |
| 3 | academic | 学術的関心を持つ読者 | WeasyPrint | 構造的。先行研究との位置づけ | ✓ |
| 4 | internal | 内部開発者 | WeasyPrint | 管理書類含む全体像 | ✗ |

### 2.2 共通のトーン原則（全種別）

すべての出力に共通する声:

- **上から教えない**: 著者は一人の探究者（S31）。権威的にならない
- **断定を避けすぎない**: 仮説でも、pjdhiroの体験に裏打ちされた確信は明確に書く
- **たとえで入る**: 抽象概念は必ず身近な体験・メタファーを添える
- **問いで閉じる**: 読者に考えさせて終わる。正解を与えない

---

## 3. 除外規則（公開3種共通）

### 3.1 公開版に含めてはならないもの

| 除外対象 | 理由 |
|---------|------|
| `docs/` 配下全ファイル | プロジェクト管理書類 |
| `sessions/` 配下全ファイル | セッション記録 |
| `transform/scripts/` 配下全ファイル | 運用スクリプト |
| `.claude/` 配下全ファイル | Claude Code設定 |
| `.github/` 配下全ファイル | GitHub設定 |
| `codex/` 配下全ファイル | LLM交換物（管理・交換ログ） |

### 3.2 公開版で使用してよいもの

| 使用可能素材 | 内容 |
|-------------|------|
| `base/schema/` | コア定義（D1-D4）、構造モデル |
| `base/text/` | 理論コンテンツ（M1意識OS、M2創造プロセス等） |
| `base/evidence/` | 論拠DB（足場として参照可能） |
| `base/expression/` | 表現DB |
| `base/voice/` | 著者の声（value baseから引用可能） |
| `resources/images/` | 構造図 |

---

## 4. 導入文の設計

### 4.1 方針の変更（v1.0→v2.0）

v1.0: 「これは何か」を伝え、定義へ橋渡し
v2.0: **「あなたに関係がある」と感じさせ、体験的に入る**

導入文は「論文の序章」ではなく「休憩所で隣に座った人への語りかけ」（S29）。

### 4.2 導入文の配置

| 種別 | ファイル | 入口のパターン |
|------|---------|---------------|
| general | `transform/introductions/intro-general.md` | 日常の違和感から。「感じたことありませんか？」 |
| designer | `transform/introductions/intro-designer.md` | プロジェクトの行き詰まりから。「なぜうまくいかないのか」 |
| academic | `transform/introductions/intro-academic.md` | 先行研究の「隙間」から。「まだ記述されていないもの」 |

### 4.3 導入文の構成（共通骨格）

1. **体験的入口**（2-3文）: 読者が「あ、それ」と思う場面
2. **本書の視点**（2-3文）: pjdhiroがどこからこれを見ているか
3. **注意書き**（1-2文）: 「全てが仮説。一人の探究者の現在地」
4. → 本文へ接続

---

## 5. ファイル構成と物語構造の関係

### 5.0 2つのレイヤの役割（v2.3明確化）

本仕様の§5は **「どの素材ファイルを使うか」の素材マッピング** を定義する。
一方、`transform/reader-rules/` は **「どういう物語構造で語るか」の変換ルール** を定義する。

```
pdf-output-spec §5 = 素材マッピング（何を使うか）
reader-rules       = 物語構造（どう語るか）
```

designer版を例にすると：
- §5.2は「core-definitions.md、five-stages.md、m1 part-1〜5 を使う」と素材を指定
- reader-rules-designer v2.1は「3幕構成（直感の分解→共感の解剖→なぜ待てないのか）で語る」と構造を指定
- ドラフト生成時、Claude Codeは **reader-rules の物語構造に従い、§5の素材から組み立てる**

### 5.1 pjdhiro用（私用・非公開）

```
base/ 全体 → generate-spec-pjdhiro.md の指示に従い自動生成 → drafts/
```

設計意図: 著者自身が読み返して「観測射撃」するための内省版。base/の素材を generate-spec-pjdhiro.md の構成指示に従って自動組み立てする。導入文なし。

**生成パイプライン**: `/generate-drafts`（Claude Code）→ `transform/drafts/kesson-pjdhiro-draft.md`

### 5.2 一般向け（general）

**素材マッピング**:
```
1. はじめに          ← transform/introductions/intro-general.md
2. 核となる考え方    ← base/schema/core-definitions.md（圧縮版）
3. 創造の構造とプロセス ← base/text/m2-creation-process/five-stages.md
```

**物語構造**: `transform/reader-rules/reader-rules-general.md` に従う

設計意図: 核心だけを伝える。「面白い」と思える体験を優先。1,500〜2,500字。

### 5.3 設計者向け（designer）

**素材マッピング**:
```
1. はじめに              ← transform/introductions/intro-designer.md
2. コア定義              ← base/schema/core-definitions.md
3. 創造の構造とプロセス  ← base/text/m2-creation-process/five-stages.md
4. 意識の作動構造        ← base/text/m1-consciousness-os/part-1 〜 part-5
5. 用語集               ← base/schema/（用語定義を含む）
```

**物語構造**: `transform/reader-rules/reader-rules-designer.md` **v2.1** に従う（3幕構成）

設計意図: 上記の素材を、reader-rulesの3幕構成（直感の分解→共感の解剖→なぜ待てないのか）に再構成して提示。

### 5.4 学術的関心向け（academic）

**素材マッピング**:
```
1. はじめに              ← transform/introductions/intro-academic.md
2. 用語体系              ← base/schema/core-definitions.md
3. 創造の構造とプロセス  ← base/text/m2-creation-process/five-stages.md
4. 意識の作動構造        ← base/text/m1-consciousness-os/part-1 〜 part-5
5. 臨床・発達心理学      ← base/text/clinical-psychology/phase4-complete.md
6. 付録: 数理（スピノル）    ← base/text/m2-creation-process/spinor-five-stages.md
7. 付録: 構造図          ← resources/images/
```

**物語構造**: `transform/reader-rules/reader-rules-academic.md` に従う

設計意図: 全コンテンツを含む完全版。ただし「学術論文」ではなく「構造類似を示す探索的記述」。

### 5.5 内部開発者向け（internal）

**素材マッピング**:
```
1. リポジトリ概要        ← README.md
2. 学術版の全内容        ← §5.4と同一
3. プロジェクト管理      ← docs/ 配下
```

**ドラフト不要**: WeasyPrintスクリプト（`build-pdf-weasyprint.py`）が base/ と docs/ から直接組み立てる。`/generate-drafts` の対象外。

---

## 6. ドラフト管理

### 6.1 ドラフトのメタ情報（v2.3新設）

全ドラフトのYAML frontmatterに以下を含める：

```yaml
---
title: "{タイトル}"
audience: "{pjdhiro|general|designer|academic}"
generated: "{ISO8601日時}"
reader_rules_version: "{参照したreader-rulesのバージョン}"
base_commit: "{git rev-parse --short HEAD}"
status: "auto-generated draft（手で編集しないこと）"
---
```

これにより、ドラフトの鮮度・生成元が常に追跡可能。

### 6.2 drafts/ のファイル一覧

| ファイル | 生成元 | 手動編集 |
|---------|--------|---------|
| `kesson-pjdhiro-draft.md` | `/generate-drafts`（generate-spec-pjdhiro.md） | ✗ |
| `kesson-general-draft.md` | `/generate-drafts`（reader-rules-general.md） | ✗ |
| `kesson-designer-draft.md` | `/generate-drafts`（reader-rules-designer.md v2.1） | ✗ |
| `kesson-academic-draft.md` | `/generate-drafts`（reader-rules-academic.md） | ✗ |
| `_pjdhiro-prompt.md` | `generate-draft.sh`（プロンプト。中間生成物） | ✗ |

**注意**: drafts/ のファイルは全て自動生成。手で編集しない。問題があれば base/ または reader-rules を修正して再生成する。

---

## 7. スクリプト構成

### 7.1 統合フロー（推奨）

```
/publish-pdf（Claude Codeコマンド）
  ├─ Phase 1: /generate-drafts → 4種ドラフト生成
  ├─ Phase 2: publish-pdf.sh --build → 5種PDFビルド
  └─ Phase 3: publish-pdf.sh --push → 公開3種push
```

### 7.2 ビルドスクリプト（2系統）

| スクリプト | エンジン | 対象 | 出力ファイル名 |
|-----------|---------|------|--------------| 
| `transform/scripts/build-pdf-lualatex.sh` | pandoc/lualatex | pjdhiro, general, designer | `kesson-pjdhiro.pdf`, `kesson-general.pdf`, `kesson-designer.pdf` |
| `transform/scripts/build-pdf-weasyprint.py` | WeasyPrint | academic, internal | `kesson-academic.pdf`, `kesson-internal.pdf` |

### 7.3 統合スクリプト

| スクリプト | 役割 |
|-----------|------|
| `transform/scripts/publish-pdf.sh` | 全5種ビルド → pjdhiroリポジトリにpush（公開3種のみ。pjdhiro/internalは非公開） |

### 7.4 部分実行

| やりたいこと | コマンド/スクリプト |
|-------------|-------------------|
| ドラフトだけ生成 | `/generate-drafts` |
| ビルドだけ | `./transform/scripts/publish-pdf.sh --build` |
| pushだけ | `./transform/scripts/publish-pdf.sh --push` |
| 特定種だけビルド | `./transform/scripts/build-pdf-lualatex.sh --audience {種別}` |
| 一括（ドラフト→ビルド→push） | `/publish-pdf` |

### 7.5 出力先

- ビルド: `build/` ディレクトリ
- 公開: pjdhiro リポジトリ `assets/pdf/`（pjdhiro/internal は除外）
- ファイル名にビルド日時を含める（SaaS型管理）

---

## 8. 品質チェック

PDF出力に対する品質チェック項目:

| # | チェック項目 | 内容 |
|---|-------------|------|
| Q1 | 管理資料除外 | 公開3種にプロジェクト管理文書が含まれていないこと |
| Q2 | 導入文の存在 | 各公開版に読者別の導入文があること |
| Q3 | ファイル構成一致 | 本仕様§5のファイル構成と実際のスクリプト定義が一致すること |
| Q4 | レンダリング確認 | 日本語フォント、表、コードブロックが正常に表示されること |
| Q5 | 画像確認 | 学術版の構造図が正常に表示されること |
| Q6 | **声の一致** | 各版のトーンがpjdhiro-values-base.mdの方針と一致すること |
| Q7 | **論文トーン排除** | 「証明する」「立証する」「考察する」等の学術論文用語が不適切に使われていないこと |
| Q8 | **仮説の明示** | 断定すべきでない箇所に温度表現（§1.1）が使われていること |
| Q9 | **投影スイッチ回避**（designer） | reader-rules v2.1 §4-bの禁止表現が含まれていないこと |
| Q10 | **立ち位置明示**（designer） | 冒頭に§2-bパターンが含まれていること |
| Q11 | **返却の設計**（designer） | §7-bの安全弁・L0誘導が含まれていること |
| Q12 | **ドラフトメタ情報** | frontmatterにgenerated/reader_rules_version/base_commitが含まれていること |

---

## 9. reader-rulesへの影響

各reader-rulesファイルは本仕様に合わせて以下の方向で改訂が必要:

| ファイル | 状態 | 主な改訂方向 |
|---------|------|-------------|
| reader-rules-general.md | v1.0 | 概ね方向性は合っている。§8トーンに「探究者の語り」を明記 |
| reader-rules-designer.md | **v2.1** | ✅ 改訂済み。投影スイッチ・返却の設計・L0誘導を含む |
| reader-rules-academic.md | v1.0 | 「学術論文」から「構造類似を探索する読み物」へ。最も改訂幅が大きい |
| reader-rules-blog.md | v1.0 | ブログは元々読み物なので方向性は一致。pjdhiro-values-base.mdへの参照を追加 |

**注意**: reader-rulesの個別改訂は本TASKの範囲外。本仕様で方向を示し、個別改訂は別TASKとする。

---

## 10. TODO

- [x] 本仕様v2.0作成
- [x] pjdhiro種別追加（v2.1）
- [x] PDF出力フロー統合（v2.3）: /publish-pdf 一括化、メタ情報ルール
- [ ] 導入文3種の改訂（`transform/introductions/`）— v2.0方針に合わせて
- [ ] reader-rules general/academic版の改訂（§9の方向に沿って）
- [ ] 全5種ビルド＆品質チェック（§8 Q6-Q12の新規チェック項目を含む）

---

## 更新履歴

| 日付 | バージョン | 内容 |
|------|-----------|------|
| 2026-02-04 | 1.0 | 初版作成（論文出力仕様） |
| 2026-02-06 | 2.0 | **根本改訂**: 論文→読み物。S27-S29, S31, pjdhiro-values-base.md に基づく |
| 2026-02-07 | 2.1 | pjdhiro種別追加（§2.1, §5.0, §6）。5種体制に移行。Session 7a/7b反映 |
| 2026-02-09 | 2.3 | **PDF出力フロー統合**: §5に素材/物語構造の2レイヤ説明追加。§6ドラフトメタ情報新設。§7フロー一括化。internal版ドラフト不要を明記。designer Q9-Q12追加 |
