# docs/README.md — プロジェクト管理ハブ

**バージョン**: 3.8
**更新日**: 2026-02-07

本ファイルは、セッション起動・運用・同期の**唯一の管理ハブ**である。
session-bootstrap.md, sync-protocol.md の内容を統合し、一本化した。

---

## 1. プロジェクトの目的と位置づけ

プロジェクトデザイン論の完成。その重要部品として「欠損駆動思考」を精緻化する。
M2（スピノル5段階）は完成済み。

**リポジトリ**: `uminomae/kesson-driven-thinking`（GitHub, Private）

### 位置づけ（LOG-20260207）

| 層 | 性格 | 備考 |
|----|------|------|
| 基盤 | 著者の認知アーキテクチャの記述 | 自明の前提。一次データの源泉 |
| 形式 | 哲学的記述 × 思想書 | 体験の構造記述。科学論文ではない |
| 将来 | 実践知の体系化 | 需要が確認された段階で展開 |

- 評価基準：科学的実証ではなく、体験の構造記述の精度と有用性
- 想定読者：AI社会で人間の思考を問い直したい人、思秋期に自己の世界観を再構築しようとする人
- [P][M][S]タグは内部作業の足場。最終出力には含めない

---

## 2. セッション開始手順

Claudeは新セッションで以下を**順番に**実行する。

**推奨起動テキスト**: `再開したい`

### Step 0: 環境判定（Claudeが自動実行）

利用可能ツールを確認し、環境を判定：

| 判定基準 | 環境 | ルート |
|---------|------|--------|
| `github:` ツールが存在 | DTアプリ + MCP | → Step 1A |
| `github:` ツールなし | ウェブ版 | → Step 1B |

### Step 1A: 管理書類の参照（DTアプリ）

GitHub APIで直接取得：

| 優先度 | 対象 | 取得方法 |
|--------|------|----------|
| 1 | docs/README.md | `github:get_file_contents` |
| 2 | docs/CURRENT.md | `github:get_file_contents` |
| 3 | docs/quality-management.md | 必要時のみ |

**PKは参照しない**。GitHub正本を直接読む。

### Step 1B: 管理書類の参照（ウェブ版）

`project_knowledge_search` で参照：

| 優先度 | 対象 | 目的 |
|--------|------|------|
| 1 | docs/README.md（本ファイル） | 運用ルール全体 |
| 2 | docs/quality-management.md | 品質チェック・テストスイート |
| 3 | docs/CURRENT.md | 進捗・残タスク |

**同期確認**: CURRENT.md の最終更新日付を確認 → 古い場合はユーザーに同期を促す。

### Step 2: 重複チェック（毎セッション冒頭）

情報は**1箇所のみ**に存在すべき。以下を確認し、違反があれば報告：

| 層 | 役割 | 重複NG |
|----|------|--------|
| Memory | ユーザーの原則・好み（PKに書けないもの） | PKと同じ内容を持たない |
| PK: README.md | 運用手順 | quality-management/CURRENTと重複しない |
| PK: quality-management.md | 品質ルール・テストスイート | README/CURRENTと重複しない |
| PK: CURRENT.md | 進捗・タスク・決定事項 | README/quality-managementと重複しない |

**肥大化チェック**: CURRENT.md §5（累積決定事項）が20行超なら圧縮を提案。

問題なければ報告不要。違反時のみユーザーに報告し、修正案を提示する。

### Step 3: 現状報告（簡潔に）

Phase・進捗・引き継ぎ事項・残タスクを把握しユーザーに報告。

### Step 4: 方針確認

ユーザーがタスク指定済みなら確認不要で着手。

**タスク種別によるロード戦略**:
- 計画的タスク（対象ファイルが明確）→ §12のファイルカタログから必要ファイルを特定し、PKガードが追加ロード
- 探索的タスク（方向が未定）→ Tier 1＋CURRENT.md §4.0バインディンググラフで開始。探索の方向が見えた段階でPKガードが段階的に追加ロード

---

## 3. コア定義（D1-D4）

| ID | 定義 |
|----|------|
| D1 | **欠損駆動思考**：棄却される誤差を、問いとして拾う態度 |
| D2 | **欠損（Kesson）**：予想と現実の誤差を、意識が「欠け」として捉えた主観的経験 |
| D3 | **Withhold**：反射的に処理せず、誤差を問いとして保持する機能 |
| D4 | **情動の構成**：欠損がF軸（生存）とO軸（愛）で評価され、情動として構成されるプロセス |

**詳細**: `base/schema/core-definitions.md`

---

## 4. エージェント構成

**標準（常時）**: 🔍欠損検出、✨概念精緻化、⚖️批評、🔮統合、🔎PKガード、📋プロセスガード、🩺セッションヘルス

**専門（必要時）**: 神経科学、Bion、Klein、Meltzer、Bowlby、日本思想、東洋哲学、西洋哲学、数学、物理

**詳細**: `docs/quality-management.md` §2

---

## 5. 品質チェック（9項目）

| # | チェック項目 | 対象 |
|---|-------------|------|
| 1 | コア定義との整合性 | 理論内容 |
| 2 | 5段階/4層との対応 | 理論内容 |
| 3 | レイヤ分離 [P][M][S] | 理論内容 |
| 4 | 群盲象チェック（3領域以上） | 理論内容 |
| 5 | 牽強付会チェック | 理論内容 |
| 6 | 運用整合性テスト（OPS） | プロジェクト運用 |
| 7 | フラクタル整合性テスト | 理論のスケール横断性 |
| 8 | しっくり感チェック（pjdhiro身体的検証） | pjdhiro判定 |
| 9 | Container機能チェック（読者体験の品質） | transform層出力時 |

**詳細**: `docs/quality-management.md` §1, §5.4

---

## 6. 運用ルール

### 6.1 対話形式

- エージェント間で議論を進め、ユーザーには**選択肢と質問**を提示
- ユーザーのメタ認知を支援。一方的に答えを出さず、合意を明示確認

### 6.2 出力ルール

#### DTアプリの場合

```
Claude → GitHub APIで直接コミット
  ↓
完了（inbox/経由不要、PK同期不要）
```

#### ウェブ版の場合

```
Claude.ai → inbox/ にファイル群 + _instructions.md を出力
  ↓
ユーザー → ダウンロードして inbox/ に配置
  ↓
Claude Code → /sync 実行（_instructions.md に従いgit操作）
  ↓
ユーザー → claude.ai PK手動同期
```

**ユーザーに手動でgit操作させない。**

### 6.3 正本の原則

```
GitHub リポジトリ = 正本（single source of truth）
Project Knowledge = GitHubの同期先（読み取り専用の鏡）
```

PKを直接編集・削除しない。すべての変更はGitHubに対して行う。

---

## 7. 同期プロトコル

### 7.1 PK同期対象

#### Tier 1: 全文保持（セッション冒頭で参照）

| ファイル | 同期タイミング |
|---------|-------------|
| `docs/README.md` | 変更時 |
| `docs/quality-management.md` | 変更時 |
| `docs/CURRENT.md` | **毎セッション終了時** |

#### Tier 2: 全文保持・検索管理（PKガードが管理）

PKに全文を保持するが、セッション冒頭では参照しない。
タスク遂行中にPKガード（quality-management.md §2.1.1）が必要性を判定し、
必要な場合のみ検索・参照する。
_instructions.mdにTier 2の内容を元にしたstr_replace指示を書いてはならない（§13）。

**PK同期対象外**: `archive/`, sessions/, base/, transform/,
outputs/（GitHub専用。必要時にClaude Codeで参照）

### 7.2 セッション終了時の必須手順

#### DTアプリの場合

1. Claudeが `docs/CURRENT.md` 更新案を作成
2. ユーザー確認後、`github:create_or_update_file` で直接コミット
3. 他のdocs/変更も同様に直接コミット
4. **PK同期は不要**（次回ウェブ版使用時にまとめて同期）

#### ウェブ版の場合

1. Claudeが `docs/CURRENT.md` 更新案を `inbox/` に出力
2. `inbox/_instructions.md` を同梱
3. ユーザーが確認 → inbox/にダウンロード → Claude Codeで `/sync`
4. docs/ に変更があった場合も同様にinbox/経由
5. ユーザーがPK手動同期

**詳細（ファイル命名・git操作）**: `archive/session-protocol.md`（廃止済み。必要時のみ参照）

### 7.3 同期確認（ウェブ版のみ）

セッション開始時、CURRENT.md の最終更新日付を確認 → 古い場合はユーザーに同期を促す。

---

## 8. 3層アーキテクチャ

```
【UI層】出力 ← 読者・媒体に最適化
    ↑
【変換層】← 読者別ルール、組み立てガイド
    ↑
【DB層】データ ← 論拠、表現、検討ログ、スキーマ
```

**詳細**: `docs/architecture.md`（GitHub専用）

---

## 9. ディレクトリ構造

```
kesson-driven-thinking/
├── base/              # DB層
│   ├── schema/        # 構造モデル（core-definitions.md）
│   ├── concepts/      # 概念ノート（CN-001〜）
│   ├── evidence/      # 論拠DB
│   ├── expression/    # 表現DB
│   ├── voice/         # 著者声DB
│   └── text/          # 理論コンテンツ（m1, m2, clinical-psychology）
├── transform/         # 変換層（introductions, scripts, drafts）
├── outputs/           # UI層（PDF成果物）
├── docs/              # 管理書類（CURRENT.md, decision-log/ を含む）
├── codex/             # Codex⇄Claude交換ハブ
│   ├── inbox/         # Claude→Codex（依頼・ブリーフィング）
│   ├── output/        # Codex→Claude（REPORT出力・正本）
│   └── archive/       # Codexレポート退避（参照化済み）
├── archive/           # 廃止・完了した文書。PK同期対象外
├── inbox/             # Claude.ai → Claude Code 受け渡し
├── sessions/          # セッション記録
└── resources/images/  # 構造図
```

---

## 10. 参照優先順位

| 優先度 | 参照先 |
|--------|--------|
| 1 | コア定義（D1-D4）→ `base/schema/core-definitions.md` |
| 2 | 品質管理 → `docs/quality-management.md` |
| 3 | 進捗 → `docs/CURRENT.md` |
| 4 | アーキテクチャ → `docs/architecture.md` |
| 5 | 検討ログ → `docs/decision-log/` |
| 6 | 表現DB → `base/expression/` |

---

## 12. ファイルカタログ（Tier 2）

以下はPKに全文保持するが、セッション冒頭では参照しない。
PKガード（quality-management.md §2.1.1）がタスクに応じて検索を管理する。
_instructions.md作成時は§13のルールに従うこと。

### 管理書類

| パス | 役割 | 主な参照元 |
|------|------|-----------| 
| `docs/architecture.md` | 3層アーキテクチャ詳細 | README §8 |
| `docs/pdf-output-spec.md` | PDF出力仕様（読者別5種） | publish-pdf.sh, build-pdf-*.sh/.py |

### ブリーフィング

| パス | 役割 | 主な参照元 |
|------|------|-----------| 
| `docs/briefings/briefing-lists-deepdive.md` | 外部LLMブリーフィング（EV-BZ-015/016/017の各論深掘り） | docs/CURRENT.md §3「残タスク」#13 |

### 概念ノート

| パス | 役割 | 主な参照元 |
|------|------|-----------| 
| `base/concepts/CN-002_f-axis-exposure.md` | F軸露出概念ノート（動機の誤認＋3層比喩） | base/concepts/index.md |
| `base/concepts/CN-003_boundary-casebook.md` | 境界ケースブック（Withhold 3↔4 / 4↔5 / 5↔6） | base/concepts/index.md |
| `base/concepts/CN-004_collective-withhold.md` | 集団Withhold最小ルーブリック（ISS-34） | base/concepts/index.md |

### スキーマ

| パス | 役割 | 主な参照元 |
|------|------|-----------| 
| `base/schema/container-mapping.md` | Container6類型×7段階の対応表（兆候→介入） | base/text/m1-consciousness-os/part-5-withhold.md |
| `base/schema/withhold-matching-v2.md` | 有向7×7マッチング表v2（観測指標付き） | base/text/m1-consciousness-os/part-5-withhold.md |

### 変換ルール・生成指示

| パス | 役割 | 主な参照元 |
|------|------|-----------| 
| `transform/reader-rules/reader-rules-blog.md` | ブログ変換ルール（pjdhiro Jekyll） | Claude.ai Skills（jekyll-pjdhiro） |
| `transform/reader-rules/blog-dark-theme-css.md` | ブログ用Dark CSSブロック | reader-rules-blog.md §4 |
| `transform/generate-spec-pjdhiro.md` | pjdhiro用生成指示書（章構成・素材指定） | generate-draft.sh |

### スクリプト

| パス | 役割 | 主な参照元 |
|------|------|-----------| 
| `transform/scripts/sync.sh` | ダウンロード→inbox移動 | .claude/commands/sync.md |
| `transform/scripts/publish-pdf.sh` | 全5種PDFビルド＋pjdhiro push（pjdhiro/internal非公開） | .claude/commands/publish-pdf.md, pdf-output-spec.md §6 |
| `transform/scripts/build-pdf-lualatex.sh` | pandoc/lualatex版PDFビルド（pjdhiro, general, designer） | publish-pdf.sh, pdf-output-spec.md §6 |
| `transform/scripts/build-pdf-weasyprint.py` | WeasyPrint版ビルド（academic, internal） | publish-pdf.sh |
| `transform/scripts/generate-draft.sh` | pjdhiro用ドラフト生成（base/ → drafts/） | build-pdf-lualatex.sh |

### Claude Codeコマンド

| パス | 役割 | 主な参照元 |
|------|------|-----------| 
| `.claude/commands/sync.md` | /sync コマンド定義 | README §6.2 |
| `.claude/commands/publish-pdf.md` | /publish-pdf コマンド定義 | README §12 |
| `.claude/commands/generate-drafts.md` | /generate-drafts コマンド定義（公開3種） | pdf-output-spec.md §6 |

### Codex入出力

| パス | 役割 | 主な参照元 |
|------|------|-----------| 
| `codex/codex_README.md` | Codex⇄Claude交換ハブ規約 | docs/README.md §12 |
| `codex/output/` | Codexレポート出力先（正本） | codex/codex_README.md |
| `codex/archive/deepdive/` | 旧deepdiveレポートのアーカイブ | codex/codex_README.md |
| `codex/output/REPORT-briefing-lists-deepdive.md` | 経営学一覧表38項目深掘りレポート（TC-012適用） | TASK #13, EV-BZ-015/016/017 |

### 外部サイト

| パス | 役割 | 主な参照元 |
|------|------|-----------| 
| `_pages/pd/thinking/thinking-kesson.md` | pjdhiroサイト: 欠損駆動思考ページ | （外部。リポジトリ内からの参照なし） |

### 画像

| パス | 役割 | 主な参照元 |
|------|------|-----------| 
| `resources/images/` 内3点 | 構造図（4層、5段階、全体） | pdf-output-spec.md §5.3, build-pdf-weasyprint.py |

### スキル

| パス | 役割 | 主な参照元 |
|------|------|-----------| 
| `skills/codex-agent/SKILL.md` | Codex並列タスク管理（タスク設計・レビュー・信頼キャリブレーション） | Codex関連の全作業 |
| `skills/codex-agent/references/track-record.md` | Codex実績ログ（成長するナレッジ） | SKILL.md §Trust Calibration |

---

## 13. _instructions.md の書き方ルール

### 原則

`_instructions.md` は**意図と方針**を伝える文書である。
Claude Codeが正本を読んで具体的な編集を実行する。

### 禁止

- 具体的な検索文字列（str_replace用）をClaude.aiが書くこと
  - 理由: PKの内容はGitHub正本と乖離している可能性がある
  - Claude.aiが見ているのはPKのテキスト（鏡）であり、正本ではない

### 記載すべき内容

1. **何をしたいか**（目的）
2. **どのファイルに対して**（パス）
3. **どの箇所を**（セクション番号、見出し名など）
4. **どう変えるか**（方針・新しい内容）
5. **コミットメッセージ**

### 例

悪い例:
  検索文字列: "TPSのノイズフロア低減≠D2の欠損。ノイズフロアが..."
  置換文字列: "測定誤差と欠損の区別は013-E冒頭注意参照..."

良い例:
  対象: base/evidence/evidence-business-org.md
  箇所: 013-F セクション内、ノイズフロアに言及している箇所
  方針: TC-004関連の重複記述を削除し、013-E冒頭注意への参照に置き換える
  Claude Codeは正本を読んで該当箇所を特定し、編集すること

---

## 14. 更新履歴

| 日付 | バージョン | 内容 |
|------|-----------|------|
| 2025-02-03 | 1.0 | 初版作成 |
| 2026-02-03 | 1.2 | 出力ルール・正本の原則追加 |
| 2026-02-04 | 2.0 | session-bootstrap.md・sync-protocol.md を統合。PK削減（11→8点） |
| 2026-02-04 | 2.1 | Step 2 重複チェック追加 |
| 2026-02-05 | 3.0 | Tier分類導入。§12ファイルカタログ・§13指示書ルール新設。PK全文保持を3点に限定 |
| 2026-02-05 | 3.1 | PKガード常設化。Tier 2を「カタログのみ」→「全文保持・PKガード管理」に変更 |
| 2026-02-05 | 3.2 | 📋プロセスガード常設化。§12に参照元列追加。§4重複解消 |
| 2026-02-05 | 3.3 | ブリーフィング（経営学一覧表015/016/017深掘り）をTier 2に追加 |
| 2026-02-06 | 3.4 | 環境自動判定追加（§2 Step 0）。DTアプリ/ウェブ版の分岐ルート（§2, §6.2, §7.2） |
| 2026-02-07 | 3.5 | §1に位置づけ（LOG-20260207）追加。評価基準・想定読者・タグ方針を明記 |
| 2026-02-07 | 3.6 | §12: 新規ファイル登録（CN-002, generate-spec-pjdhiro, generate-draft.sh, build-pdf-lualatex.sh）。5種体制反映。§9にconcepts/追加 |
| 2026-02-07 | 3.7 | §9にcodex/追加。§12に「Codex入出力」セクション新設（REPORT-briefing-lists-deepdive.md登録） |
| 2026-02-07 | 3.8 | codex/codex_README.md追加。旧 inbox/deepdive REPORT を codex/archive/deepdive に移設。Codex出力先を codex/output に統一 |
