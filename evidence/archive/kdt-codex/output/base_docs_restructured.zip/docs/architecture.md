# アーキテクチャ v2.3

**バージョン**: 2.3
**作成日**: 2026-02-07
**配置先**: `docs/architecture.md`（差し替え）

---

## 1. 概要

本プロジェクトは、理論コンテンツを複数の読者・媒体に変換して出力するために、3層アーキテクチャを採用している。

```
【出力層】      outputs/              ← 最終出力（PDF、漫画等）
    ↑
【変換層】      transform/            ← 導入文、変換ルール、スクリプト
    ↑
【基盤層】      base/                 ← 変換の入力資源（対話結果＋先行研究）
```

管理書類は `docs/` に一括して配置する（3層の外）。

---

## 2. 基盤層（base/）

変換に用いるための資源全てを格納する。対話結果と先行研究との対比がメイン。

```
base/
├── schema/                   # 構造モデル
│   ├── core-definitions.md   # D1-D4
│   ├── four-layers.md        # 4層モデル
│   ├── five-stages.md        # 5段階モデル
│   ├── four-modules.md       # 4モジュール
│   ├── container-mapping.md  # Withhold: 兆候→Container対応表
│   └── withhold-matching-v2.md # Withhold: 有向7×7マッチング表v2
│
├── evidence/                 # 論拠DB（先行研究との対比）
│   ├── evidence-neuroscience.md      # EV-NS: 情報処理としての脳
│   ├── evidence-life-sciences.md     # EV-LS: エネルギー・代謝としての脳 ★新設
│   ├── evidence-psychoanalysis.md
│   ├── evidence-philosophy.md
│   ├── evidence-mathematics.md
│   ├── evidence-creativity.md
│   ├── evidence-cognitive-science.md
│   ├── evidence-developmental-psychology.md
│   ├── evidence-aesthetics.md
│   ├── evidence-business.md
│   ├── evidence-business-org.md
│   ├── evidence-business-lists.md
│   ├── evidence-business-decision.md
│   └── evidence-business-design.md
│
├── expression/               # 表現DB（一文表現）
│   └── core/
│       ├── E01.md ... E10.md
│
├── voice/                    # pjdhiro発言集
│   └── pjdhiro-statements-db.md
│
├── concepts/                 # 概念ノート
│   ├── index.md              # 概念ノート一覧
│   └── CN-***.md             # 個別概念ノート
│
└── text/                     # 本文（対話結果・セッション成果物）
    ├── m1-consciousness-os/
    │   ├── part-1-introduction.md
    │   ├── part-2-interoception.md
    │   ├── part-3-prediction-error.md
    │   ├── part-4-fo-evaluation.md
    │   └── part-5-withhold.md
    ├── m2-creation-process/
    │   ├── five-stages.md
    │   └── spinor-five-stages.md
    └── foundation/
        └── phase1-summary.md
```

### base/ の構成要素

| ディレクトリ | 内容 | 性質 |
|-------------|------|------|
| `schema/` | D1-D4, 4層, 5段階, 4モジュール | 構造モデル（理論の骨格） |
| `evidence/` | 論拠DB（ドメイン別） | 先行研究との対比 |
| `expression/` | E01-E10 | 一文表現（理論の結晶） |
| `voice/` | pjdhiro発言集 | 対話結果（意思決定の記録） |
| `concepts/` | 概念ノート | 概念の関係性・精緻化の経緯 |
| `text/` | M1, M2, 本文 | 対話結果（セッション成果物） |

### 2.3 論拠DB（base/evidence/）

ドメイン別に先行研究との対比を格納する。

| ファイル | ドメインID | 対象 | エントリ数 |
|---------|-----------|------|-----------|
| evidence-neuroscience.md | EV-NS | 情報処理としての脳（ニューロン中心） | 9 |
| evidence-life-sciences.md | EV-LS | エネルギー・代謝としての脳（グリア中心） | 7 |
| evidence-psychoanalysis.md | EV-PA | 精神分析（Bion, Klein等） | — |
| evidence-philosophy.md | EV-PH | 哲学（西田、和辻等） | — |
| evidence-mathematics.md | EV-MA | 数学（スピノル等） | — |
| evidence-creativity.md | EV-CR | 創造性研究 | — |
| evidence-cognitive-science.md | EV-CS | 認知科学 | — |
| evidence-developmental-psychology.md | EV-DP | 発達心理学 | — |
| evidence-aesthetics.md | EV-AE | 美学・芸術 | — |
| evidence-business*.md | EV-BZ | ビジネス（4ファイル） | — |

**EV-NS / EV-LS の境界**: 情報処理 = EV-NS、エネルギー/代謝 = EV-LS。同一現象の異なる記述モード（S20: 情報とエネルギーは同型だが記述は分ける）。

### 2.5 概念ノート（base/concepts/）

概念間の結合、精緻化の経緯、誤解防止の注記を格納する。

**設計意図**:
- schema/（構造）、expression/（表現）、evidence/（論拠）を**横断する概念の関係性**を記録
- 「なぜこの定義に至ったか」の文脈を保持
- 探索的に発展する概念の成長履歴を追跡
- 既存言語体系との差異・誤解防止を明示

**必須セクション**:
1. 概念の核心（一文定義）
2. なぜこの概念が必要か
3. 概念の構造（下位概念、関連概念との境界）
4. 誤解されやすいポイント
5. pjdhiro発言との接続
6. 成長履歴
7. 群盲象チェック

**Codex影響範囲**: base/concepts/ は Codex 更新対象外。Claude.ai セッションで追加・更新する。

---

## 3. 変換層（transform/）

基盤層の素材を読者別・媒体別に組み立てる。

```
transform/
├── introductions/            # 読者別導入文
│   ├── intro-general.md
│   ├── intro-designer.md
│   └── intro-academic.md
├── reader-rules/             # 変換ルール
│   ├── reader-rules-general.md
│   ├── reader-rules-designer.md
│   ├── reader-rules-academic.md
│   ├── reader-rules-blog.md
│   └── blog-dark-theme-css.md
└── scripts/                  # ビルドスクリプト
    ├── build-pdf-lualatex.sh
    ├── build-pdf-weasyprint.py
    ├── publish-pdf.sh
    └── sync.sh
```

### 読者別出力

| 種別 | 読者 | エンジン | 公開 |
|------|------|---------|------|
| general | 一般 | pandoc/lualatex | ✓ |
| designer | プロジェクト設計者 | pandoc/lualatex | ✓ |
| academic | 学術専門家 | WeasyPrint | ✓ |
| internal | 内部開発者 | WeasyPrint | ✗ |
| blog | AI協働に関心のある技術者 | Jekyll/Minimal Mistakes | ✓ |
| manga | 一般（漫画） | 未定 | ✓（将来） |

---

## 4. 出力層（outputs/）

最終出力物を格納する。

```
outputs/
├── pdf/                      # PDF出力
│   ├── kesson-general.pdf
│   ├── kesson-designer.pdf
│   ├── kesson-academic.pdf
│   └── kesson-internal.pdf
└── manga/                    # 漫画出力（将来）
```

**配信先**:
- pjdhiro `assets/pdf/` — 公開PDF（general, designer, academic）

---

## 5. 管理（docs/）

プロジェクト管理書類を一括して配置する。3層の外に位置する。

```
docs/
├── README.md                 # 管理ハブ
├── quality-management.md     # 品質管理
├── architecture.md           # 本文書
├── pdf-output-spec.md        # PDF出力仕様
├── phase6-charter.md         # Phase 6 憲章
├── CURRENT.md                # 進捗・残タスク
├── decision-log/             # 検討ログ
│   ├── index.md
│   └── 2026-02/
│       └── LOG-*.md
└── briefings/                # 外部LLMブリーフィング
    └── briefing-*.md
```

---

## 6. その他のディレクトリ

| ディレクトリ | 役割 | 備考 |
|-------------|------|------|
| `inbox/` | Claude.ai → Claude Code 受け渡し | .gitignore で *.md を無視（ただし deepdive/ は除外解除） |
| `codex/inbox/` | Claude → Codex 受け渡し（依頼・ブリーフィング） | 既存briefingはgrandfather |
| `codex/output/` | Codex並列作業のレポート出力先（正本） | REPORT-*.md |
| `codex/archive/` | Codexレポートのアーカイブ | 旧 `inbox/deepdive/` を移設 |
| `inbox/deepdive/` | （レガシー）旧Codexレポート置き場 | 現在は `codex/` に移行 |
| `skills/` | プロジェクト固有スキル（Claude.ai標準構造） | PK同期対象。SKILL.md + references/ |
| `resources/images/` | 構造図（BSPL.jpg等） | |
| `archive/` | 廃止・完了した文書 | |
| `.claude/commands/` | Claude Code カスタムコマンド | |

---

## 7. 全体構造（まとめ）

```
kesson-driven-thinking/
│
├── base/                     # 基盤層：変換の入力資源
│   ├── schema/               # 構造モデル
│   ├── evidence/             # 論拠DB ← Codex更新対象
│   ├── expression/           # 表現DB
│   ├── voice/                # pjdhiro発言集
│   ├── concepts/             # 概念ノート
│   └── text/                 # 本文（M1, M2）
│
├── transform/                # 変換層
│   ├── introductions/        # 読者別導入文
│   ├── reader-rules/         # 変換ルール
│   └── scripts/              # ビルドスクリプト
│
├── outputs/                  # 出力層
│   ├── pdf/
│   └── manga/
│
├── docs/                     # 管理（3層の外）
│   ├── README.md
│   ├── quality-management.md
│   ├── architecture.md
│   ├── pdf-output-spec.md
│   ├── CURRENT.md
│   ├── decision-log/
│   └── briefings/
│
├── inbox/                    # 受け渡し
│   └── deepdive/             # Codexレポート出力先
├── skills/                   # プロジェクト固有スキル
│   └── codex-agent/          # Codex協業管理
├── resources/                # 画像等
├── archive/                  # 廃止文書
└── README.md
```

---

## 8. 移行マッピング

### 8.1 リネーム・移動

| 現在 | 新規 | 備考 |
|------|------|------|
| `db/` | 廃止 | 内容を分散 |
| `db/evidence/` | `base/evidence/` | 移動 |
| `db/expression/` | `base/expression/` | 移動 |
| `db/decision-log/` | `docs/decision-log/` | 管理へ統合 |
| `db/pjdhiro/` | `base/voice/` | 移動＋リネーム |
| `schema/` | `base/schema/` | 移動 |
| `content/` | `base/text/` | 移動＋リネーム |
| `content/m1-consciousness-os/` | `base/text/m1-consciousness-os/` | |
| `content/m2-creation-process/` | `base/text/m2-creation-process/` | |
| `content/foundation/` | `base/text/foundation/` | |
| `content/integration/` | `archive/integration/` | 作業中→アーカイブ |
| `content/clinical-psychology/` | 要確認 | 使用状況による |
| `content/terminology/` | 要確認 | 使用状況による |
| `context/CURRENT.md` | `docs/CURRENT.md` | 管理へ統合 |
| `scripts/` | `transform/scripts/` | 移動 |

### 8.2 廃止

| ディレクトリ | 理由 |
|-------------|------|
| `context/` | CURRENT.md を docs/ に移動後、廃止 |
| `sessions/` | archive/ に統合 or 廃止 |

---

## 9. 設計原則

1. **3層分離**: 基盤層 → 変換層 → 出力層の単方向依存
2. **base/ 集約**: 変換の入力資源は全て base/ に
3. **docs/ 統合**: 管理書類は全て docs/ に一括
4. **名前で性質がわかる**: base = 基盤、transform = 変換、outputs = 出力
5. **Codex影響範囲の限定**: Codexは base/evidence/ のみ更新

---

## 10. 更新履歴

| 日付 | バージョン | 内容 |
|------|-----------|------|
| 2026-02-04 | 1.0 | 初版作成 |
| 2026-02-05 | 2.0 | 3層再設計。db/→base/、content/→base/text/、docs/統合 |
| 2026-02-06 | 2.1 | §2.5 概念ノート追加。§2ツリー図・構成要素表・§7全体構造に反映 |
| 2026-02-06 | 2.2 | §2.3 論拠DB一覧追加。EV-LS（生命科学）新設を反映。evidence/ツリー図を実態と整合 |
