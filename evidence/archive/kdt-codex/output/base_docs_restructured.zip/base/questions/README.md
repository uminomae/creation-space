# Questions (Q&A)

このディレクトリは「よくある質問」= 概念辞書の入口。

- `Q-trust.md`
- `Q-creativity.md`

各QはConcept Card(s)へリンクする。
