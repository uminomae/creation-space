# Q: creativity

## 一文回答

（TODO）

## 定義（あなた版）

（TODO）

## 操作的定義（観測）

（TODO）

## 関連概念

- 

## 根拠

- 
