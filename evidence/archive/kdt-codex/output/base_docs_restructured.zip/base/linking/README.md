# Linking

このディレクトリは「概念 ↔ 主張 ↔ 根拠」のトレーサビリティを置く。

- `matrix-concept-evidence.csv`: 概念カードと根拠カードの対応
- `matrix-claim-concept.csv`: 主張（expression）と概念の対応
- `matrix-claim-evidence.csv`: 主張と根拠の対応
