---
file_id: EV-NS
domain: neuroscience
last_updated: 2026-02-03
entry_count: 9
sync_target: Project Knowledge（変更時のみ）
backup: GitHub db/evidence/evidence-neuroscience.md
---

# 論拠DB：神経科学（Neuroscience）

**目的**: 4層モデル（Layer 0-3）を支える神経科学的論拠の集積。

**凡例**: [P] 実験的事実・確立理論 / [M] 理論から着想した解釈 / [S] 検証可能な仮説

---

## EV-NS-001: 予測符号化と自由エネルギー原理

- **layer**: [P]
- **claims**:
  - 脳は階層的ベイズ推論で予測誤差を最小化する
  - 上位層が予測を送り、下位層が誤差を返す双方向処理
  - 精度（precision）が誤差の重みづけを制御（注意の計算論的実装）
  - 自由エネルギー原理は予測符号化を包含する統一的枠組み
- **supports**: D1（棄却される誤差＝精度の低い予測誤差）, D2（予想と現実の誤差）, E01, E04
- **4layer**: Layer 1（予測-誤差ループ）の基盤理論
- **refs**:
  - Friston, K. (2010). The free-energy principle. *Nature Reviews Neuroscience*, 11(2), 127-138.
  - Clark, A. (2013). Whatever next? *Behavioral and Brain Sciences*, 36(3), 181-204.
  - Rao, R. P., & Ballard, D. H. (1999). Predictive coding in the visual cortex. *Nature Neuroscience*, 2(1), 79-87.
  - Bastos, A. M., et al. (2012). Canonical microcircuits for predictive coding. *Neuron*, 76(4), 695-711.
  - Feldman, H., & Friston, K. J. (2010). Attention, uncertainty, and free-energy. *Frontiers in Human Neuroscience*, 4, 215.
- **used_in**: Phase 3 Part 3, 学術論文版ドラフト

---

## EV-NS-002: 内受容感覚（Interoception）

- **layer**: [P]
- **claims**:
  - 内受容感覚は身体内部状態（心拍、呼吸、腸管等）の知覚
  - 前部島皮質が統合・意識化の中枢
  - 内受容にも予測符号化が適用（内受容的推論）
  - 情動・自己感の基盤を提供
- **supports**: D2（欠損の身体的基盤）, D4（情動の構成）, E07
- **4layer**: Layer 0（内受容感覚）の直接的根拠
- **refs**:
  - Craig, A. D. (2009). How do you feel — now? *Nature Reviews Neuroscience*, 10(1), 59-70.
  - Seth, A. K., & Friston, K. J. (2016). Active interoceptive inference and the emotional brain. *Phil Trans R Soc B*, 371(1708), 20160007.
  - Barrett, L. F., & Simmons, W. K. (2015). Interoceptive predictions in the brain. *Nature Reviews Neuroscience*, 16(7), 419-429.
- **used_in**: Phase 3 Part 2 (Layer 0), Phase 4 Part 2

---

## EV-NS-003: 情動の構成理論

- **layer**: [P]
- **claims**:
  - 情動は脳が能動的に構成する（構成主義的情動理論）
  - ソマティック・マーカー仮説：身体信号が意思決定を導く
  - 扁桃体がF軸（脅威評価）の中枢
  - 情動は内受容予測と外受容文脈の統合として生じる
- **supports**: D4（情動の構成）, E08
- **4layer**: Layer 2（F-O評価）の理論的基盤
- **refs**:
  - Barrett, L. F. (2017). *How Emotions Are Made*. Houghton Mifflin Harcourt.
  - Damasio, A. R. (1994). *Descartes' Error*. Putnam.
  - Bechara, A., & Damasio, A. R. (2005). The somatic marker hypothesis. *Games and Economic Behavior*, 52(2), 336-372.
  - LeDoux, J. E. (1996). *The Emotional Brain*. Simon & Schuster.
  - Frijda, N. H. (1986). *The Emotions*. Cambridge University Press.
  - Lazarus, R. S. (1991). *Emotion and Adaptation*. Oxford University Press.
- **used_in**: Phase 3 Part 4, Phase 4 Part 3, 学術論文版ドラフト

---

## EV-NS-004: 実行機能とWithholdの神経基盤

- **layer**: [P+M]
- **claims**:
  - [P] dlPFC（背外側前頭前野）が認知的制御・反応抑制を担う
  - [P] ACC（前帯状皮質）が葛藤モニタリング・誤差検出
  - [P] vmPFC（腹内側前頭前野）が価値評価・情動調整
  - [M] Withhold ≠ 単なる反応抑制。dlPFC+ACC+vmPFCの協働で「問いとして保持」を実現
- **supports**: D3（Withhold）, E02, E06
- **4layer**: Layer 3（Withhold）の直接的根拠
- **refs**:
  - Miller, E. K., & Cohen, J. D. (2001). An integrative theory of prefrontal cortex function. *Annual Review of Neuroscience*, 24, 167-202.
  - Botvinick, M. M., et al. (2001). Conflict monitoring and cognitive control. *Psychological Review*, 108(3), 624-652.
- **used_in**: Phase 3 Part 5, 学術論文版ドラフト

---

## EV-NS-005: 意識と統合

- **layer**: [P]
- **claims**:
  - 意識はグローバル・ワークスペースへの情報ブロードキャストとして理解可能
  - 統合情報理論（IIT）：意識は統合情報量（Φ）と相関
  - 「制御された幻覚」（Seth）：意識的知覚は脳の最良の予測
- **supports**: D2（「意識が欠けとして捉えた」の科学的位置づけ）
- **4layer**: Layer 1 の意識化メカニズム
- **refs**:
  - Dehaene, S., & Changeux, J. P. (2011). Experimental and theoretical approaches to conscious processing. *Neuron*, 70(2), 200-227.
  - Tononi, G. (2008). Consciousness as integrated information. *Biological Bulletin*, 215(3), 216-242.
  - Seth, A. K. (2021). *Being You*. Dutton.
- **used_in**: Phase 3 Part 3 §3.2

---

## EV-NS-006: 睡眠夢と予測-誤差ループ

- **layer**: [P+M]
- **claims**:
  - [P] REM睡眠中も予測的処理が作動、DMNが活性化
  - [M] 夢の中でも欠損が経験される（運動・論理・記憶の欠損）
  - [M] Layer 1 が高次認知（Layer 2-3）から独立した基本プロセスである証拠
- **supports**: D2（欠損の基本性）
- **4layer**: Layer 1 の独立性の証拠
- **refs**:
  - Hobson, J. A., et al. (2000). Dreaming and the brain. *Behavioral and Brain Sciences*, 23(6), 793-842.
  - Nir, Y., & Tononi, G. (2010). Dreaming and the brain. *Trends in Cognitive Sciences*, 14(2), 88-100.
  - Domhoff, G. W., & Fox, K. C. (2015). Dreaming and the default network. *Consciousness and Cognition*, 33, 342-353.
- **used_in**: Phase 3 Part 3 §3.4

---

## EV-NS-007: ポリヴェーガル理論

- **layer**: [P+M]
- **claims**:
  - [P] 自律神経系は3段階構造（背側迷走・交感・腹側迷走）
  - [P] 腹側迷走神経系が社会的関与（social engagement）を支える
  - [M] Withholdには腹側迷走の活性化（安全感）が前提条件
- **supports**: D3（Withholdの条件）, E10
- **4layer**: Layer 3 の生理学的前提
- **refs**:
  - Porges, S. W. (2011). *The Polyvagal Theory*. Norton.
  - Porges, S. W. (2007). The polyvagal perspective. *Biological Psychology*, 74(2), 116-143.
- **used_in**: Phase 3（計画段階）, Phase 4 Part 2, Part 4
- **notes**: ポリヴェーガル理論は一部批判あり。階層構造は[P]、Withholdとの接続は[M]

---

## EV-NS-008: デフォルトモードネットワーク（DMN）

- **layer**: [P]
- **claims**:
  - DMNは安静時・内省時に活性化する脳ネットワーク
  - 自己参照的処理、回想・展望、メンタライゼーションに関与
  - タスク正ネットワークと拮抗関係
- **supports**: 背景的（D2の内省的側面）
- **4layer**: 背景的論拠（特定Layerに限定されない）
- **refs**:
  - Raichle, M. E., et al. (2001). A default mode of brain function. *PNAS*, 98(2), 676-682.
  - Buckner, R. L., et al. (2008). The brain's default network. *Ann NY Acad Sci*, 1124, 1-38.
- **used_in**: Phase 3（計画段階で参照）
- **notes**: 創造5段階「場」とDMN活性化の対応は[S]

---

## EV-NS-009: 身体化された認知

- **layer**: [P+M]
- **claims**:
  - [P] 認知は脳・身体・環境の相互作用から生じる（エナクティヴィズム）
  - [P] 知覚は能動的な意味生成プロセス
  - [M] 欠損は身体的プロセスなしには生じない
- **supports**: D2（欠損の身体性）, E07, E04（AI対比）
- **4layer**: Layer 0 の哲学的基盤
- **refs**:
  - Varela, F. J., Thompson, E., & Rosch, E. (1991). *The Embodied Mind*. MIT Press.
  - Gallagher, S. (2005). *How the Body Shapes the Mind*. Oxford University Press.
- **used_in**: Phase 3 全体, Phase 4 Part 2

---

## クロスリファレンス

### D1-D4 との対応

| 定義 | 主要論拠 |
|------|---------|
| D1（欠損駆動思考） | EV-NS-001 |
| D2（欠損） | EV-NS-001, EV-NS-002, EV-NS-005, EV-NS-006, EV-NS-009 |
| D3（Withhold） | EV-NS-004, EV-NS-007 |
| D4（情動の構成） | EV-NS-002, EV-NS-003 |

### E01-E10 との対応

| 表現 | 主要論拠 |
|------|---------|
| E01 棄却される誤差を問いとして拾う | EV-NS-001 |
| E02 待つことが分ける | EV-NS-004 |
| E04 AIは欠損を経験しない | EV-NS-001, EV-NS-002, EV-NS-009 |
| E06 すぐに解決しない | EV-NS-004 |
| E07 身体が感じなければ | EV-NS-002, EV-NS-009 |
| E08 恐れと愛 | EV-NS-003 |
| E10 安定した関係 | EV-NS-007 |

### 4層モデルとの対応

| Layer | 主要論拠 |
|-------|---------|
| Layer 0 | EV-NS-002, EV-NS-009 |
| Layer 1 | EV-NS-001, EV-NS-005, EV-NS-006 |
| Layer 2 | EV-NS-003 |
| Layer 3 | EV-NS-004, EV-NS-007 |
| 背景的 | EV-NS-008 |
