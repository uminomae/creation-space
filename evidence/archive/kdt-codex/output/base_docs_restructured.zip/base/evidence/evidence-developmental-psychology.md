---
file_id: EV-DP
domain: developmental-psychology
last_updated: 2026-02-05
entry_count: 4
sync_target: Project Knowledge（変更時のみ手動同期）
backup: GitHub base/evidence/evidence-developmental-psychology.md
---

# 論拠DB：発達心理学（Developmental Psychology）

**目的**: 4層モデル（L0-L3）とWithhold（D3）の発達的基盤を、代表的発達理論と実行機能研究から補強する。

**凡例**:
- **[P]** 文献に基づく解釈
- **[M]** 理論から着想した構造的類似
- **[S]** 検証可能な仮説
- **[HOLD]** 保留（一次ソース確認後に再検討）

**関連表現**: E10（ただし、ひとりでは待てない）

**選定基準（ISS-25）**: Bowlby（愛着）だけではO軸偏重になるため、L1/L3（認知発達/実行機能）側の論拠を追加する方針。以下の4人は認知（Piaget）、社会文化（Vygotsky）、心理社会（Erikson）、神経発達（EF研究）の代表として選定。

---

## EV-DP-001: Piaget 認知発達（同化/調節/均衡化）

- **layer**: [P+M]
- **信頼度**: 0.45
- **claims**:
  - [P] 同化（assimilation）：新しい経験を既存のスキーマに取り込む
  - [P] 調節（accommodation）：スキーマを新しい経験に合わせて修正する
  - [P] 均衡化（equilibration）：同化と調節のバランスを取り、より高次の均衡状態へ移行するプロセス
  - [P] 発達段階：感覚運動期→前操作期→具体的操作期→形式的操作期
  - [M] L1（予測モデル）の発達を「スキーマの成熟」として語れる外部フックになりうる
  - [M] 調節 ≈ 予測モデルの更新（予測誤差への適応）
  - **[M] 重要な差異（ISS-26）**: 
    - 均衡化は「誤差を解消する方向」に向かう（不均衡→均衡）
    - 欠損駆動思考は「誤差を保持する」ことを重視（D3: Withhold）
    - したがって、Piagetは"誤差検出"の説明には使えるが、"誤差保持"の説明には直接使えない
- **supports**: L1（予測モデルの発達）の外部フック
- **4layer**: Layer 1（予測-誤差ループの発達）
- **5stages**: 波〜縁（差異の検出と調整）
- **refs**:
  - Piaget, J. (1952). *The Origins of Intelligence in Children*. International Universities Press.
  - Piaget, J. (1970). *Genetic Epistemology*. Columbia University Press.
- **cross_ref**: EV-NS-002（予測符号化）
- **used_in**: M1（4層の発達的説明）
- **判断コンテキスト**:
  - **結論**: 採用候補（要レビュー）
  - **判断の要点**: L1の発達を語る外部フックとして有用だが、本論との差異（均衡化≠欠損保持）を明示する必要がある
  - **根拠**: REPORT-20260205-005, ISS-26
  - **代替案**: Piagetは"差異"中心で言及し、主導線はVygotsky（関係/Container）へ寄せる
  - **限界**: 一次ソース確認前。Piagetの用語を本論語彙へ過剰変換しない（文脈保持）
  - **次アクション**: 同化/調節の原典定義を確認し、D1/D2との関係（欠損≠不均衡）を明文化

---

## EV-DP-002: Vygotsky ZPD/足場かけ

- **layer**: [P+M]
- **信頼度**: 0.55
- **claims**:
  - [P] 最近接発達領域（ZPD: Zone of Proximal Development）：子どもが独力では達成できないが、より有能な他者の援助があれば達成できる発達の領域
  - [P] 足場かけ（scaffolding）：学習者の能力に応じて支援を調整し、徐々に撤去していくプロセス（Wood, Bruner, & Ross, 1976 による拡張）
  - [P] 内言（inner speech）：外的な社会的言語が内面化され、思考の道具となるプロセス
  - [P] 発達は社会的相互作用の内面化として進む
  - [M] **E10「ひとりでは待てない」の発達的根拠**: 
    - Withholdは独力では発達しない
    - 外的Container（養育者、教師、仲間）が「待つ」ことを支援する
    - その支援が徐々に内面化され、自己のWithhold能力となる
  - [M] 外的Container → 内在化 の図式がD3（Withhold）の発達を説明する
  - [M] ZPD ≈ 「まだ自分では保持できないが、支えられれば保持できる」領域
  - [S] Withhold能力のZPDを測定できれば、介入設計に使える可能性
- **supports**: D3（Withhold）の発達、E10（ひとりでは待てない）
- **4layer**: Layer 3（Withhold）の発達的基盤
- **5stages**: 縁〜渦（他者との関係が個としてのまとまりを支える）
- **refs**:
  - Vygotsky, L. S. (1978). *Mind in Society: The Development of Higher Psychological Processes*. Harvard University Press.
  - Wood, D., Bruner, J. S., & Ross, G. (1976). The role of tutoring in problem solving. *Journal of Child Psychology and Psychiatry*, 17(2), 89-100.
- **cross_ref**: EV-PA-002（Bion containment）, EV-PA-006（Bowlby 愛着）, EV-BZ-009（センゲ学習組織）
- **used_in**: M1/M3（関係が支えるWithhold）
- **判断コンテキスト**:
  - **結論**: 採用候補（温度感⬆️、ISS-29）
  - **判断の要点**: E10「ひとりでは待てない」の発達根拠として最も強い。外的Container→内在化の説明がD3に直結
  - **根拠**: REPORT-20260205-005, base/expression/core/E10.md
  - **代替案**: 教育文脈に閉じるなら適用範囲を限定（[文脈]保持）
  - **限界**: 原典の範囲（教育/文化）を逸脱しない
  - **次アクション**: ZPDと心理的安全性（EV-BZ-017-i）との接続を検討。一次ソースで「内言」の発達過程を確認

---

## EV-DP-003: Erikson 心理社会的発達

- **layer**: [P+M]
- **信頼度**: 0.40
- **claims**:
  - [P] 8つの発達段階：各段階に心理社会的「危機」（crisis）がある
  - [P] 主要概念：
    - 基本的信頼 vs 不信（乳児期）
    - 自律性 vs 恥・疑惑（幼児前期）
    - 主導性 vs 罪悪感（幼児後期）
    - 勤勉性 vs 劣等感（学童期）
    - 同一性 vs 役割混乱（青年期）
    - 親密性 vs 孤立（成人前期）
    - 世代性 vs 停滞（成人期）
    - 統合性 vs 絶望（老年期）
  - [P] 危機の解決は「徳」（virtue）の獲得につながる
  - [M] 発達段階の「危機」を欠損経験の型として整理できる可能性：
    - 危機 = 予測モデルと現実の不一致が顕在化するタイミング
    - 解決 = 予測モデルの再構築（Piagetの調節と類似）
  - [M] F-O分解（D4）との親和性：
    - 基本的信頼 → O軸の基盤
    - 自律性 → F軸の基盤（自己効力感）
  - [S] 各段階の「危機」をF-O座標上にマッピングできる可能性
- **supports**: D4（F-O評価）の発達的側面、M1（発達）
- **4layer**: Layer 2（F-O評価）の発達
- **5stages**: 各段階が5段階の異なる相に対応する可能性（要検証）
- **refs**:
  - Erikson, E. H. (1950). *Childhood and Society*. W. W. Norton.
  - Erikson, E. H. (1968). *Identity: Youth and Crisis*. W. W. Norton.
- **cross_ref**: EV-PA-006（Bowlby 愛着）, EV-DP-001（Piaget）
- **used_in**: D4説明、M1（発達）
- **判断コンテキスト**:
  - **結論**: 採用候補（要レビュー、ISS-27）
  - **判断の要点**: 発達段階の「危機」を欠損経験の型として整理できる可能性があるが、段階論は粗いので一部概念のみ採用が現実的
  - **根拠**: REPORT-20260205-005
  - **代替案**: 段階論全体ではなく、信頼/自律など一部概念のみ採用
  - **限界**: 段階論の文化差・実証性の扱いに注意。批判的研究も参照すべき
  - **次アクション**: 主要概念（基本的信頼、自律性）をE表現へ落とすか検討。ISS-27で採用範囲を確定

---

## EV-DP-004: 実行機能（EF）とWithhold

- **layer**: [P+M]
- **信頼度**: 0.65
- **claims**:
  - [P] 実行機能（Executive Function）の3要素（Miyake et al., 2000）：
    - 抑制（Inhibition）：優勢反応の抑制
    - 更新（Updating）：ワーキングメモリの内容更新
    - 切替（Shifting）：課題間の注意切替
  - [P] 前頭前野（PFC）が実行機能の神経基盤
  - [P] 実行機能は幼児期から青年期にかけて発達する（発達的軌跡）
  - [P] マシュマロテスト（Mischel）：遅延報酬課題での抑制能力と長期的成功の相関
  - [M] **Withhold（D3）と抑制（Inhibition）の関係**:
    - 抑制 = 行動の出力を止める（必要条件）
    - Withhold = 誤差を「問いとして保持する」（抑制 + 意味付け）
    - したがって、抑制はWithholdの神経基盤だが、Withhold ≠ 抑制（D3の弁別を維持）
  - [M] 更新 ≈ L1（予測モデルの更新）
  - [M] 切替 ≈ L2での評価軸の切り替え（F→O、O→F）
  - [M] 実行機能の発達 = Withhold能力の神経的成熟
  - [S] EFの発達段階とWithholdの成熟を対応づける表が作成可能
- **supports**: D3（Withhold）の神経発達的基盤
- **4layer**: Layer 3（Withhold）の神経基盤
- **5stages**: 渦（まとまりの保持）→ 束（方向付き出力）の制御
- **refs**:
  - Miyake, A., Friedman, N. P., Emerson, M. J., Witzki, A. H., Howerter, A., & Wager, T. D. (2000). The unity and diversity of executive functions and their contributions to complex "frontal lobe" tasks: A latent variable analysis. *Cognitive Psychology*, 41(1), 49-100.
  - Mischel, W., Shoda, Y., & Rodriguez, M. L. (1989). Delay of gratification in children. *Science*, 244(4907), 933-938.
  - Diamond, A. (2013). Executive functions. *Annual Review of Psychology*, 64, 135-168.
- **cross_ref**: EV-NS-004（実行機能）, EV-PA-002（Bion containment）
- **used_in**: D3説明、M1（Withhold機構）
- **判断コンテキスト**:
  - **結論**: 採用候補（リポジトリ内根拠強め、ISS-28）
  - **判断の要点**: Withholdを「単なる抑制ではない」としつつ、抑制（EF）を神経基盤の必須要素として位置づける判断は既にEV-NS-004にある。発達側へ橋をかける役割
  - **根拠**: base/evidence/evidence-neuroscience.md（EV-NS-004）, content/m1-consciousness-os/part-5-withhold.md, base/expression/core/E10.md
  - **代替案**: EFは神経科学に閉じ、発達心理学では「外的支援→内在化」（Vygotsky）中心にする
  - **限界**: EF ≠ Withhold の弁別を必ず維持。「問いとして保持」の意味論的側面はEFでは説明できない
  - **次アクション**: EFの発達段階とWithholdの成熟を対応づける表を作成。CR-002（EV-NS-004のクロスリファレンス）との統合

---

## 群盲象チェック（D3: Withhold の発達的基盤）

| 領域 | 概念 | 構造 | 検証状態 |
|------|------|------|---------|
| 認知発達 | Piaget 調節 | 誤差→スキーマ修正 | ✅（ただし均衡化≠保持） |
| 社会文化 | Vygotsky ZPD | 外的支援→内在化 | ✅ |
| 心理社会 | Erikson 危機 | 欠損経験の型 | 🔶候補 |
| 神経発達 | 実行機能 | 抑制の発達 | ✅ |
| 精神分析 | Bion containment | β→α変換の発達 | ✅（EV-PA参照） |
| 精神分析 | Bowlby 愛着 | 安全基地→探索 | ✅（EV-PA参照） |

**現状**: 4領域（認知/社会文化/神経発達/精神分析）通過済み + 1領域候補（心理社会）

---

## 更新履歴

| 日付 | 内容 |
|------|------|
| 2026-02-05 | 初版作成。EV-DP-001〜004を定義。ISS-25〜29を反映 |
