---
file_id: EV-PA
domain: psychoanalysis
last_updated: 2026-02-03
entry_count: 10
sync_target: Project Knowledge（変更時のみ手動同期）
backup: GitHub db/evidence/evidence-psychoanalysis.md
---

# 論拠DB：精神分析（Psychoanalysis）

**概要**: 4層モデルの臨床的・発達的基盤を支える精神分析理論の論拠。Phase 4の主要成果を集約。

**凡例**:
- **[P]** 臨床観察・実験的事実
- **[M]** 理論から着想した解釈・比喩
- **[S]** 検証可能な仮説

---

## Bion理論

### EV-PA-001: α機能と4層モデル

- **layer**: [P+M]
- **claims**:
  - [P] α機能は未処理の感覚・情動体験（β要素）を思考可能な形（α要素）に変換する
  - [P] Bionは意図的にα機能を未定義とした（具体化を避けるため）
  - [M] α機能は4層モデルの層間移行プロセスとして位置づけられる
  - [M] β要素 ≈ Layer 0-1 の生の予測誤差、α要素 ≈ Layer 2 で情動的に評価された欠損
  - [S] α機能の神経相関は、島皮質→前頭前野への情報移行に対応する可能性
- **supports**: D2（欠損の変換過程）, D4（情動の構成）
- **4layer**: Layer 0-1 → Layer 2 の変換プロセス
- **refs**:
  - Bion, W. R. (1962). *Learning from Experience*. Heinemann.
  - Hopkins, J. (2018). Making worlds in a waking dream: Where Bion intersects Friston. *Frontiers in Psychology*, 9, 1674.
- **used_in**: Phase 4 Part 1, 学術論文版ドラフト

---

### EV-PA-002: Container-Contained

- **layer**: [P+M]
- **claims**:
  - [P] 養育者が乳児のβ要素を受け止め（contain）、消化して返す対人的プロセス
  - [P] この反復が乳児自身のα機能の内在化を促す
  - [M] Container = 外的Withhold（他者が「保持」を代行する機能）
  - [M] 安全なContainer経験がLayer 3（Withhold）の発達を支える
- **supports**: D3（Withholdの発達的起源）, E10（安定した関係が待てる力を育てる）
- **4layer**: Layer 3 の発達的基盤（外的→内的Withhold）
- **refs**:
  - Bion, W. R. (1962). *Learning from Experience*. Heinemann.
  - Bion, W. R. (1959). Attacks on linking. *International Journal of Psycho-Analysis*, 40, 308-315.
- **used_in**: Phase 4 Part 1, Part 2

---

### EV-PA-003: contact-barrierと病理

- **layer**: [P+M]
- **claims**:
  - [P] contact-barrierは意識と無意識の境界を維持する機能
  - [P] その崩壊が精神病状態の核心（Bion, 1957）
  - [M] contact-barrier ≈ Layer 1-2 間のフィルタ機能（精度閾値）
  - [S] 統合失調症の予測過剰は、contact-barrier崩壊と予測符号化の異常として統合的に理解できる
- **supports**: 精神疾患の4層分類
- **4layer**: Layer 1-2 間のインターフェース障害
- **refs**:
  - Bion, W. R. (1957). Differentiation of the psychotic from the non-psychotic personalities. *International Journal of Psycho-Analysis*, 38, 266-275.
- **used_in**: Phase 4 Part 6

---

## Klein理論

### EV-PA-004: 分裂と統合（PS-D）

- **layer**: [P+M]
- **claims**:
  - [P] 妄想-分裂ポジション（PS）：対象を全面的に良い/悪いに分裂させる
  - [P] 抑うつポジション（D）：良い対象と悪い対象を同一として統合する
  - [P] PS→Dは一方向でなく、生涯にわたり振動する
  - [M] 分裂 = F軸とO軸の非統合（恐れと愛が別々の対象に向かう）
  - [M] 統合 = F-O統合（同一対象に恐れと愛を同時に向けられる）
  - [S] vmPFCがF-O統合の神経基盤であり、その機能不全がBPDの中核
- **supports**: D4（情動の構成）, E08（恐れと愛）
- **4layer**: Layer 2（F-O評価）の臨床的裏付け
- **refs**:
  - Klein, M. (1946). Notes on some schizoid mechanisms. *International Journal of Psycho-Analysis*, 27, 99-110.
  - Segal, H. (1973). *Introduction to the Work of Melanie Klein*. Hogarth Press.
  - Zilcha-Mano, S., et al. (2021). Neuroscience of object relations in health and disorder. *Frontiers in Psychology*, 12, 583743.
- **used_in**: Phase 4 Part 3, 統合文書

---

### EV-PA-005: 投影同一視

- **layer**: [P+M]
- **claims**:
  - [P] 自己の一部を対象に投影し、その対象と同一化する心的操作
  - [P] 対人的影響力を持つ（相手に実際に感情を誘発する）
  - [M] 4層モデルで完全には捉えきれない側面がある（対人境界の問題）
  - [M] Layer 0 の間主観的起源と関連するが、独自の次元を持つ
- **supports**: 4層モデルの限界の明示（誠実な理論的態度）
- **4layer**: 4層で捉えきれない側面を暫定的に位置づけ
- **refs**:
  - Klein, M. (1946). Notes on some schizoid mechanisms.
  - Ogden, T. H. (1989). *The Primitive Edge of Experience*. Jason Aronson.
- **used_in**: Phase 4 Part 0b（暫定的位置づけ）

---

## Meltzer理論

### EV-PA-006: 美的葛藤

- **layer**: [P+M]
- **claims**:
  - [P] 対象の美しさに惹かれつつ、その内部を知ることへの恐れが同時存在する
  - [P] この葛藤は乳児の母親知覚に始まり、芸術体験・創造に至る
  - [M] 美的葛藤 = F軸（怖い）+ O軸（知りたい）の同時活性化
  - [M] この葛藤をWithholdする（すぐに解消しない）ことが創造性の源泉
  - [M] 「秘すれば花」（世阿弥）と構造的に同型
- **supports**: D3（Withhold）, E05（美とは欠損を保持すること）, E06（すぐに解決しない）
- **4layer**: Layer 2（F-O同時活性化）→ Layer 3（Withhold）の臨床的論拠
- **refs**:
  - Meltzer, D., & Harris Williams, M. (1988). *The Apprehension of Beauty*. Clunie Press.
- **used_in**: Phase 4 Part 5, 美と保持の統合, E05, E06

---

## Bowlby理論

### EV-PA-007: 愛着理論の基礎

- **layer**: [P]
- **claims**:
  - 乳児と養育者の間の情緒的絆（愛着）は生存に不可欠な生物学的システム
  - 内部作業モデル（IWM）が自己と他者についての予測モデルを形成
  - 愛着の4類型：安定型、回避型、不安型、無秩序型
  - 愛着パターンは生涯にわたり対人関係に影響する
- **supports**: E10（安定した関係が待てる力を育てる）
- **4layer**: O軸の発達的基盤
- **refs**:
  - Bowlby, J. (1969/1982). *Attachment and Loss: Vol. 1. Attachment*. Basic Books.
  - Ainsworth, M. D. S., et al. (1978). *Patterns of Attachment*. Erlbaum.
  - Main, M., & Hesse, E. (1990). Parents' unresolved traumatic experiences are related to infant disorganized attachment status. In M. T. Greenberg et al. (Eds.), *Attachment in the Preschool Years*.
- **used_in**: Phase 4 Part 4

---

### EV-PA-008: 愛着パターンの4層再解釈

- **layer**: [M+S]
- **claims**:
  - [M] 愛着パターンは原因ではなく、より根本的プロセスの「観察可能な表現型」
  - [M] 安定型 = α機能 + F-O統合が良好
  - [M] 回避型 = O軸の抑制（Layer 2）
  - [M] 不安型 = O軸の過敏（Layer 2）
  - [M] 無秩序型 = F-O非統合（Layer 2-3）
  - [S] 愛着パターンの変化は、α機能指標とF-O統合指標で予測可能
- **supports**: D4（情動の構成）, E08, E10
- **4layer**: Layer 2-3 の発達的個人差
- **refs**:
  - Fonagy, P., et al. (2002). *Affect Regulation, Mentalization, and the Development of the Self*. Other Press.
  - Rutter, M., et al. (2007). Effects of profound early institutional deprivation. *European Journal of Developmental Psychology*, 4(3), 332-350.
- **used_in**: Phase 4 Part 4

---

## 発達心理学

### EV-PA-009: 間主観性とLayer 0の社会的起源

- **layer**: [P+M]
- **claims**:
  - [P] 一次的間主観性：新生児期から養育者との情動的同調が存在する
  - [P] 二次的間主観性：9ヶ月頃から対象を介した三者関係が成立
  - [P] 社会的アロスタシス：他者との調整を通じて身体状態を管理する
  - [M] Layer 0（内受容感覚）は孤立した個体内プロセスではなく、間主観的に発達する
  - [M] 「身体が感じる」能力自体が社会的関係の中で育まれる
- **supports**: E07（身体が感じなければ）, E10（安定した関係）
- **4layer**: Layer 0 の発達的・社会的基盤
- **refs**:
  - Trevarthen, C. (1979). Communication and cooperation in early infancy. In M. Bullowa (Ed.), *Before Speech*.
  - Trevarthen, C., & Hubley, P. (1978). Secondary intersubjectivity. In A. Lock (Ed.), *Action, Gesture and Symbol*.
  - Fotopoulou, A., & Tsakiris, M. (2017). Mentalizing homeostasis. *Neuropsychoanalysis*, 19(1), 3-28.
- **used_in**: Phase 4 Part 2

---

### EV-PA-010: 精神疾患の4層機能不全モデル

- **layer**: [M+S]
- **claims**:
  - [M] 各精神疾患は特定のLayer機能不全パターンとして理解できる
  - [S] パニック障害 = Layer 0-1（内受容感覚の誤解釈）
  - [S] GAD = Layer 1-2（誤差の過剰検出 + F軸過活性）
  - [S] 社交不安 = Layer 2（O軸のF軸化）
  - [S] BPD = Layer 2-3（F-O非統合 + Withhold不全）
  - [S] 解離性障害 = 層間連携（α機能の断片化）
  - [S] 治療は「欠損処理能力の回復」として統一的に理解できる
- **supports**: 4層モデルの臨床的有用性
- **4layer**: 全Layer の病理パターン
- **refs**:
  - APA (2013). *DSM-5*.
  - Barrett, L. F., et al. (2016). An active inference theory of allostasis and interoception in depression. *Phil Trans R Soc B*, 371(1708), 20160011.
  - Clark, D. M. (1986). A cognitive approach to panic. *Behaviour Research and Therapy*, 24(4), 461-470.
  - Linehan, M. M. (1993). *Cognitive-Behavioral Treatment of BPD*. Guilford Press.
- **used_in**: Phase 4 Part 6

---

## クロスリファレンス

### コア定義との対応

| 定義 | 主要論拠 |
|------|---------|
| D1（欠損駆動思考） | — （精神分析は直接支持しないが、α機能が概念的近似） |
| D2（欠損） | EV-PA-001（β要素→α要素の変換） |
| D3（Withhold） | EV-PA-002, EV-PA-006 |
| D4（情動の構成） | EV-PA-001, EV-PA-004, EV-PA-005 |

### 一文表現との対応

| 表現 | 主要論拠 |
|------|---------|
| E05（美とは欠損を保持すること） | EV-PA-006 |
| E06（すぐに解決しない） | EV-PA-006 |
| E08（恐れと愛） | EV-PA-004, EV-PA-006 |
| E10（安定した関係） | EV-PA-002, EV-PA-007, EV-PA-009 |

### 神経科学論拠との接続

| 精神分析概念 | 対応する神経科学論拠 |
|-------------|-------------------|
| α機能 | EV-NS-003, EV-NS-004（内受容→情動構成） |
| Container | EV-NS-012（ポリヴェーガル・安全感） |
| PS-D振動 | EV-NS-005（情動の構成理論） |
| 美的葛藤 | EV-NS-009（実行機能）, EV-NS-010（F軸） |
| 愛着 | EV-NS-012（ポリヴェーガル） |
