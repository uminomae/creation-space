---
file_id: EV-CR
domain: creativity-research
last_updated: 2026-02-05
entry_count: 18
sync_target: Project Knowledge（変更時のみ）
backup: GitHub db/evidence/evidence-creativity.md
---

# 論拠DB：創造性研究（Creativity Research）

**目的**: 創造性研究の先行研究と欠損駆動思考の接続・差異を記録。Phase 6 創造性レビューの成果を集約。

**凡例**: [P] 確立された研究成果 / [M] 本理論との解釈的接続 / [S] 検証可能な仮説

---

## EV-CR-001: Wallas 4段階モデル

- **layer**: [P+M]
- **claims**:
  - [P] 創造的思考の4段階：Preparation → Incubation → Illumination → Verification
  - [M] Incubation ≈ 場→波（意識下での揺らぎ）、Illumination ≈ 縁→渦（個の立ち上がり）
  - [M] Wallasの「問題の認識」を「欠損の経験」として再解釈
  - [M] Wallasモデルの限界：線形的・一方向（循環性の欠如）、Incubationの内部構造が不明
  - [M] 欠損駆動思考はIncubationを「波」と「縁」に分解し内部構造を記述
- **supports**: D1（創造の出発点としての欠損）, 5段階との対応
- **module**: M2
- **refs**:
  - Wallas, G. (1926). *The Art of Thought*. Jonathan Cape.
  - Sawyer, R. K. (2012). *Explaining Creativity* (2nd ed.). Oxford University Press.（段階モデルの再整理）
- **used_in**: Phase 6 創造性レビュー, 学術論文版ドラフト

#### `[類似]` 欠損駆動思考とWallasの重なり

- [類似] 「創造は段階をもつ」こと自体（プロセス記述）
- [類似] Incubation（保留/中断）が重要である点

#### `[独自]` 欠損駆動思考にありWallasにない

- [独自] 出発点を「問題」ではなく「欠損（主観的経験）」として定義（D2）
- [独自] Incubationの内部機構（波/縁、Withhold）を明示

#### `[学び]` Wallasにあり欠損駆動思考に不足

- [学び] 記述を「誰でも使える工程語彙」に落とす強さ（普及性）
- [学び] 検証（Verification）を創造プロセスに明示的に含める設計

#### `[文脈]` 理論固有の前提・適用範囲

- [文脈] 実証というより「古典的整理」。内部メカニズム説明は意図していない

#### `[判断]`（現時点: 2026-02-05）
- **結論**: 採用確定
- **信頼度**: 0.75
- **議論経緯**: Wallasの4段階は線形だが、Verification（束の後）を「再帰のトリガー」として解釈することで、本論の循環性で補完できる。検証で新たな欠損が検出されれば場に戻る。ISS-17（再帰関数モデル）に統合。
- **決定内容**: Verification = 束→場への再帰トリガー
- **限界**: 線形段階モデル。循環性は本論側で補強
- **参照**: LOG-20250202-004, LOG-20260205-001, ISS-17

#### `[判断履歴]`
| 日付 | 信頼度 | 変化 | LOG |
|------|--------|------|-----|
| 02-02 | 0.75 | 初期採用 | LOG-20250202-004 |
| 02-05 | 0.75 | Verification=再帰トリガーで確定 | LOG-20260205-001 |

---

## EV-CR-002: Guilford 発散的/収束的思考

- **layer**: [P+M]
- **claims**:
  - [P] 発散的思考（多様なアイデア生成）と収束的思考（一つの解へ収束）の区別
  - [M] 発散的思考 ≈ 場→波→縁（拡散、分離、関係探索）
  - [M] 収束的思考 ≈ 渦→束（個の確立、方向の確定）
  - [M] 5段階は二分法を超えた連続的移行として記述
  - [M] 発散的思考の神経基盤：DMN活性化 + Layer 3（Withhold）の一時的緩和
- **supports**: 5段階の前半/後半の区別
- **module**: M2
- **refs**:
  - Guilford, J. P. (1950). Creativity. *American Psychologist*, 5(9), 444-454.
  - Guilford, J. P. (1967). *The Nature of Human Intelligence*. McGraw-Hill.
- **used_in**: Phase 6 創造性レビュー

#### `[類似]`

- [類似] 「拡散→収束」のリズムは5段階の前半/後半に対応

#### `[独自]`

- [独自] 二分法（発散/収束）を5段階として分解し、段階間移行（縁・渦）を導入
- [独自] 欠損（D2）とWithhold（D3）により「なぜ発散が必要か」を説明

#### `[学び]`

- [学び] 測定可能な指標（発散性指標）へ落とす道具立て

#### `[文脈]`

- [文脈] SOI（知能構造）という心理測定の伝統に位置づく

#### `[判断]`（現時点: 2026-02-05）
- **結論**: 保留（ISS-28統合）
- **信頼度**: 0.70
- **議論経緯**: 発散/収束を4層で説明する仮説（発散=L1+L3 Withhold、収束=L2評価+L3解除）を検討。ただし「モード」と「レイヤ」は異なる次元であり、単純対応は牽強付会リスク。EF（実行機能）との関係整理が必要なためISS-28に統合。
- **論点**: 発散/収束の切替メカニズムを4層で説明できるか
- **限界**: 二分法は粗い
- **参照**: LOG-20250202-004, LOG-20260205-001, ISS-28

#### `[判断履歴]`
| 日付 | 信頼度 | 変化 | LOG |
|------|--------|------|-----|
| 02-02 | 0.70 | 初期採用 | LOG-20250202-004 |
| 02-05 | 0.70 | 4層説明をISS-28で検討 | LOG-20260205-001 |

---

## EV-CR-003: Csikszentmihalyi フロー理論とシステムモデル

- **layer**: [P+M]
- **claims**:
  - [P] フロー：挑戦と能力の均衡時に生じる最適経験
  - [P] システムモデル：創造性は個人・領域・場の相互作用から生じる
  - [M] フロー ≈ 予測誤差が「適度に」発生し即座に処理される状態
  - [M] システムモデルは4モジュールと高い親和性：Person→M1, Domain→M4, Field→M3, Process→M2
  - [M] 内発的動機 ＝ 欠損が「問い」として機能する状態（O軸優位）
- **supports**: 4モジュール構造の外部的妥当性, D4（F-O評価と動機）
- **module**: M1, M2, M3, M4
- **refs**:
  - Csikszentmihalyi, M. (1990). *Flow*. Harper & Row.
  - Csikszentmihalyi, M. (1996). *Creativity*. HarperCollins.
- **used_in**: Phase 6 創造性レビュー
- **notes**: 4モジュール←→システムモデルの対応は本理論の重要な外部的妥当性の一つ

#### `[類似]`

- [類似] 「創造は個人内では完結しない」＝ M3/M4の必然

#### `[独自]`

- [独自] フロー/創造の内側を4層（L0-L3）で機構記述する（欠損/Withhold/F-O）

#### `[学び]`

- [学び] Field（場）＝評価・門番の制度設計を創造理論に組み込む視点

#### `[文脈]`

- [文脈] 文化社会学寄り。創造物の受容/評価の説明力が核

#### `[判断]`（現時点: 2026-02-05）
- **結論**: 保留（ISS-33起票）
- **信頼度**: 0.75
- **議論経緯**: フロー中のWithhold状態を検討。仮説として「Withholdの変形」（保持ではなく即時的な問い→解の高速ループ）を提案。ただし「Withholdの変形」は新概念であり定義が必要。ISS-23（偽Withhold）との関連もあり、新規イシューISS-33として起票。
- **論点**: フロー中のWithhold状態（変形？停止？高速ループ？）
- **限界**: Withholdの位置づけが未確定
- **参照**: LOG-20250202-004, LOG-20260205-001, ISS-33

#### `[判断履歴]`
| 日付 | 信頼度 | 変化 | LOG |
|------|--------|------|-----|
| 02-02 | 0.75 | 初期採用 | LOG-20250202-004 |
| 02-05 | 0.75 | フロー中Withhold問題をISS-33起票 | LOG-20260205-001 |

---

## EV-CR-004: Amabile 構成要素モデル

- **layer**: [P+M]
- **claims**:
  - [P] 創造性の3要素：領域関連スキル、創造性関連プロセス、課題動機づけ
  - [P] 内発的動機づけ原理：外発的動機は創造性を阻害し、内発的動機は促進
  - [M] 領域関連スキル ≈ M4 + Layer 1の予測モデル精度
  - [M] 創造性関連プロセス ≈ M2 + Layer 3（Withhold）
  - [M] 課題動機づけ ≈ Layer 2（F-O評価）、特にO軸
  - [M] 外発的動機（F軸優位）vs 内発的動機（O軸優位）としてF-O軸で分解
- **supports**: D4（F-O評価と動機の質）
- **module**: M2, Layer 2
- **refs**:
  - Amabile, T. M. (1983). *The Social Psychology of Creativity*. Springer-Verlag.
  - Amabile, T. M. (1996). *Creativity in Context*. Westview Press.
- **used_in**: Phase 6 創造性レビュー

#### `[類似]`

- [類似] 「動機づけの質」が創造性を決める（D4の核心）

#### `[独自]`

- [独自] 動機をF-O 2軸に分解し、創造性阻害を“F軸支配の失敗モード”として扱う

#### `[学び]`

- [学び] 実証研究としての操作概念（内発/外発）と介入可能性（環境設計）

#### `[文脈]`

- [文脈] 組織心理学・教育心理学。測定と介入が中心

#### `[判断]`（現時点: 2026-02-05）
- **結論**: 保留（ISS-32起票）
- **信頼度**: 0.70
- **議論経緯**: 外発的動機が必ずしも阻害しない条件を検討。情報的報酬（能力フィードバック）vs 統制的報酬（行動制御）の区別がF-O評価と接続可能。統制的報酬=F軸優位→Withhold困難、情報的報酬=O軸的→Withhold維持可能という仮説を立てた。組織設計（M3）、教育への応用に直結する重要論点。
- **仮説**: 統制的報酬=F軸優位→Withhold困難、情報的報酬=O軸的→Withhold維持可能
- **論点**: 外発的動機が阻害しない条件
- **参照**: LOG-20250202-004, LOG-20260205-001, ISS-32

#### `[判断履歴]`
| 日付 | 信頼度 | 変化 | LOG |
|------|--------|------|-----|
| 02-02 | 0.70 | 初期採用 | LOG-20250202-004 |
| 02-05 | 0.70 | 外発動機問題をISS-32起票 | LOG-20260205-001 |

---

## EV-CR-005: Sawyer 協調的創造性

- **layer**: [P+M]
- **claims**:
  - [P] 創造性は個人レベルだけでなく集団レベルで創発する
  - [P] グループフロー：集団で共有されるフロー状態
  - [M] 5段階を集団レベルに適用：場（共有空間）→波（テンション）→縁（相互作用）→渦（創発）→束（合意）
  - [M] M3（事業構造）への直接的示唆
  - [M] 心理的安全性 ≈ 集団レベルのWithhold条件（ポリヴェーガル EV-NS-007と接続）
- **supports**: M3（事業構造）の理論的基盤
- **module**: M3
- **refs**:
  - Sawyer, R. K. (2007). *Group Genius*. Basic Books.
  - Sawyer, R. K. (2012). *Explaining Creativity* (2nd ed.). Oxford University Press.
- **used_in**: Phase 6 創造性レビュー
- **notes**: M3の表現追加（残タスク）の際に再参照が必要

#### `[類似]`

- [類似] 5段階を個人ではなく“相互作用の場”に適用できる

#### `[独自]`

- [独自] 集団創造をF-O軸（安全/関係）＋4層（身体基盤）で下支えする枠組み

#### `[学び]`

- [学び] 即興・会話・ターンテイキングなど、ミクロ相互作用の観察語彙

#### `[文脈]`

- [文脈] 即興芸術/教育/チーム研究の系譜。個人内モデルでは捉えない

#### `[判断]`（現時点: 2026-02-05）
- **結論**: 保留（ISS-34起票）
- **信頼度**: 0.65
- **議論経緯**: 協調的創造性とE10「ひとりでは待てない」の接続を確認。「集団Withhold」のメカニズムが未定式化。個人のWithholdと集団のWithholdは同じ構造か？という問いが浮上。スケールのフラクタル性（品質チェック#7）の検証が必要。心理的安全性、Vygotsky（ISS-29）との接続を含め、ISS-34として起票。
- **論点**: 集団Withhold / 組織的Withholdのメカニズム
- **接続**: E10、心理的安全性（EV-BZ-017-i）、Vygotsky（ISS-29）
- **参照**: LOG-20250202-004, LOG-20260205-001, ISS-34

#### `[判断履歴]`
| 日付 | 信頼度 | 変化 | LOG |
|------|--------|------|-----|
| 02-02 | 0.65 | 初期採用 | LOG-20250202-004 |
| 02-05 | 0.65 | 集団Withhold問題をISS-34起票 | LOG-20260205-001 |

---

## EV-CR-006: Boden 計算論的創造性とAI対比

- **layer**: [P+M]
- **claims**:
  - [P] 創造性の3類型：組合せ的、探索的、変換的
  - [P] 組合せ的・探索的創造性はAI実装可能、変換的は部分的
  - [M] 組合せ的 ≈ 縁（既存要素間の新しい関係）
  - [M] 探索的 ≈ 波→縁→渦（場の内部の未探索領域）
  - [M] 変換的 ≈ 場の再構成（予測モデル自体の変容）
  - [M] 欠損駆動思考の独自性：AIは予測誤差を「計算」するが「欠損」を「経験」しない
- **supports**: E04（AIは欠損を経験しない）, D2（主観的経験としての欠損）
- **module**: M2, AI論
- **refs**:
  - Boden, M. A. (1990/2004). *The Creative Mind* (2nd ed.). Routledge.
  - Boden, M. A. (Ed.). (1994). *Dimensions of Creativity*. MIT Press.
- **used_in**: Phase 6 創造性レビュー
- **notes**: 「AIが苦手なことはこの分野」（プロジェクト目標の一つ）の直接的根拠

#### `[類似]`

- [類似] 「探索」と「概念空間（場）」を中心に創造を記述

#### `[独自]`

- [独自] “計算可能性”ではなく“経験可能性（欠損）”でAI対比を立てる
- [独自] Withhold（保持）を創造の弁別子に据える

#### `[学び]`

- [学び] 計算論モデル（探索/変換）を明示し、反証可能性を高める作法

#### `[文脈]`

- [文脈] 計算論的創造性（AI/認知科学）。実装可能性に軸足

---

## EV-CR-007: Rhodes 4P（Person/Process/Product/Press）

- **layer**: [P]
- **claims**:
  - [P] 創造性を Person（個人）/ Process（過程）/ Product（産物）/ Press（環境・圧力）に分解する分類枠
  - [M] 4Pは、欠損駆動思考の4モジュール（M1-4）と部分的に整合する（ただし同一ではない）
- **supports**: 4モジュール（分解の作法）, OPS（議論の粒度管理）
- **module**: M1, M2, M3, M4
- **refs**:
  - Rhodes, M. (1961). An Analysis of Creativity. *The Phi Delta Kappan*.（要検証: 巻号/頁）
  - Runco, M. A. (2007). *Creativity: Theories and Themes*. Elsevier.
- **used_in**: Phase 6 創造性レビュー（分類枠）

#### `[類似]`

- [類似] 「創造性は単一要因ではなく、分解して扱うべき」という態度

#### `[独自]`

- [独自] 4Pを“内部機構（4層/F-O/Withhold）”へ接続し、Processを説明可能にする

#### `[学び]`

- [学び] 分解（分類）を先に固定することで、議論が混線するのを防ぐ（プロセスガード的効用）

#### `[文脈]`

- [文脈] 研究の整理枠。因果モデルではない

---

## EV-CR-008: Mednick 連想理論（Remote Associates / RAT）

- **layer**: [P+M]
- **claims**:
  - [P] 創造性は遠隔連想（remote associations）を形成する能力に関係する
  - [P] RAT（Remote Associates Test）は「離れた概念を結びつける」能力の測度として用いられる
  - [M] 遠隔連想は5段階の「縁」（関係の生成）に焦点を当てる
- **supports**: D2（欠損の“関係欠損”としての経験）, 5段階（縁）
- **module**: M2
- **refs**:
  - Mednick, S. A. (1962). The associative basis of the creative process. *Psychological Review*, 69(3), 220-232.
  - Mednick, S. A., & Mednick, M. T. (1967). *Remote Associates Test*. Houghton Mifflin.（要検証: 版）
- **used_in**: Phase 6 創造性レビュー

#### `[類似]`

- [類似] 新規性は「関係の生成（縁）」として現れる

#### `[独自]`

- [独自] “連想能力”を欠損検出（D2）とWithhold（D3）のプロセス内に位置づける

#### `[学び]`

- [学び] 縁の生成を測定する具体的タスク（RAT）

#### `[文脈]`

- [文脈] 個人内の連想・問題解決に寄る。社会的評価は外部

---

## EV-CR-009: Geneplore（生成→探索）モデル

- **layer**: [P+M]
- **claims**:
  - [P] 創造は「生成（generate）」と「探索（explore）」の反復で進む
  - [P] 生成で前アイデア（preinventive structures）を作り、探索で解釈・精緻化する
  - [M] 生成≒場→波、探索≒縁→渦 の往復として記述可能
- **supports**: M2（創造プロセスの往復運動）, D3（保持の反復）
- **module**: M2
- **refs**:
  - Finke, R. A., Ward, T. B., & Smith, S. M. (1992). *Creative Cognition: Theory, Research, and Applications*. MIT Press.
  - Ward, T. B., Smith, S. M., & Finke, R. A. (1999). Creative cognition. In *Handbook of Creativity*.（要検証: 編者/頁）
- **used_in**: Phase 6 創造性レビュー

#### `[類似]`

- [類似] 創造は一撃ではなく、生成と探索の往復で進む

#### `[独自]`

- [独自] 往復の“燃料”を欠損（D2）として定義し、止めない力をWithhold（D3）に置く

#### `[学び]`

- [学び] 生成物（preinventive）という中間成果の概念化（何を保持しているかを記述できる）

#### `[文脈]`

- [文脈] 実験心理学・認知科学。タスク設計と操作概念が中心

#### `[判断]`（現時点: 2026-02-05）
- **結論**: 採用確定
- **信頼度**: 0.65
- **議論経緯**: Generate/Exploreの往復と5段階の循環性を接続。循環条件（いつ場に戻るか）の明文化が必要。CR-001（Verification=再帰トリガー）と統合し、ISS-17（再帰関数モデル）で一括検討することを決定。
- **決定内容**: 循環条件 = 再帰の終了/継続条件（ISS-17統合）
- **限界**: 実験パラダイム由来の用語を過剰輸入しない
- **参照**: LOG-20260205-001, ISS-17

#### `[判断履歴]`
| 日付 | 信頼度 | 変化 | LOG |
|------|--------|------|-----|
| 02-02 | 0.65 | 初期採用 | LOG-20250202-004 |
| 02-05 | 0.65 | 循環条件をISS-17統合で確定 | LOG-20260205-001 |

---

## EV-CR-010: BVSR（Blind Variation & Selective Retention）

- **layer**: [P+M]
- **claims**:
  - [P] 創造は「盲目的変異（blind variation）」と「選択的保持（selective retention）」の組み合わせとして理解できる
  - [M] 変異は場/波の探索、保持はWithhold、選択は束（方向の確定）に対応
- **supports**: D1（問いとして拾う）, D3（保持）, 5段階（探索→選択）
- **module**: M2
- **refs**:
  - Campbell, D. T. (1960). Blind variation and selective retention in creative thought as in other knowledge processes. *Psychological Review*, 67(6), 380-400.
  - Simonton, D. K. (1999). *Origins of Genius*. Oxford University Press.（BVSRの展開）
- **used_in**: Phase 6 創造性レビュー

#### `[類似]`

- [類似] 「試行（変異）→選択→保持」というサイクル

#### `[独自]`

- [独自] “blind” を欠損の主観的経験（何が欠けているかわからない）として内側から記述
- [独自] 選択をF-O評価として扱い、なぜその保持が続くかを説明

#### `[学び]`

- [学び] 創造を“生成の美談”ではなく、探索と淘汰のプロセスとして冷静に扱う枠

#### `[文脈]`

- [文脈] 進化論アナロジー。創造を適応・淘汰の語彙で語る

---

## EV-CR-011: Sternberg & Lubart 投資理論（Investment Theory）

- **layer**: [P+M]
- **claims**:
  - [P] 創造的個人は「安く買って高く売る」ように、低評価のアイデアに投資し、後に価値化する
  - [P] 創造性は複数資源（知識・知能・スタイル・動機・人格・環境）の結合で生じる
  - [M] 価値化はM3（場＝評価制度）とM4（領域＝規範）の作用に依存
- **supports**: M3（評価/採用の制度）, M4（領域規範）
- **module**: M3, M4
- **refs**:
  - Sternberg, R. J., & Lubart, T. I. (1995). *Defying the Crowd: Cultivating Creativity in a Culture of Conformity*. Free Press.
  - Sternberg, R. J. (2006). The nature of creativity. *Creativity Research Journal*, 18(1), 87-98.（要検証: 書誌）
- **used_in**: Phase 6 創造性レビュー

#### `[類似]`

- [類似] 「価値は後から立ち上がる」＝ 束（確定）と場（評価）の往復

#### `[独自]`

- [独自] 価値化をF-O評価として内側からも記述し、投資の継続をWithholdで支える

#### `[学び]`

- [学び] “市場/評価”を創造理論の中心に置く（M3の必然性を強化）

#### `[文脈]`

- [文脈] 社会的評価・キャリア・制度を含む。個人内過程だけでは完結しない

---

## EV-CR-012: Kaufman & Beghetto 4C（mini-c / little-c / Pro-c / Big-C）

- **layer**: [P+M]
- **claims**:
  - [P] 創造性を4水準（個人的意味づけ〜歴史的偉業）で区別する
  - [M] “評価のスケール”を明示することで、創造の議論が混線するのを防ぐ
- **supports**: M3（評価スケール）, OPS（議論の粒度）
- **module**: M3
- **refs**:
  - Kaufman, J. C., & Beghetto, R. A. (2009). Beyond big and little: The four C model of creativity. *Review of General Psychology*, 13(1), 1-12.
  - Beghetto, R. A., & Kaufman, J. C. (2007). Toward a broader conception of creativity.（要検証: 書誌）
- **used_in**: Phase 6 創造性レビュー

#### `[類似]`

- [類似] “創造”は評価と不可分（M3）

#### `[独自]`

- [独自] mini-c（個人的創造）を欠損（主観的経験）から出発させ、4層で記述可能にする

#### `[学び]`

- [学び] 創造性のレベル差を明確にし、過剰一般化を防ぐ

#### `[文脈]`

- [文脈] 教育心理学・才能研究。評価と育成の枠組み

---

## EV-CR-013: Torrance / TTCT（発散的思考の測定と教育）

- **layer**: [P+M]
- **claims**:
  - [P] 発散的思考（fluency, flexibility, originality 等）を測定するテスト群（TTCT）
  - [M] 欠損駆動思考の“前半”（場→波→縁）を測定する足場になりうる
- **supports**: 実証研究との接続（測定可能性）, M2（発散/探索側）
- **module**: M2
- **refs**:
  - Torrance, E. P. (1966). *Torrance Tests of Creative Thinking*. Personnel Press.（要検証: 版）
  - Kim, K. H. (2006). Can we trust creativity tests? A review of TTCT. *Creativity Research Journal*, 18(1), 3-14.（要検証: 書誌）
- **used_in**: Phase 6（実証接続の足場）

#### `[類似]`

- [類似] 発散（拡散）を測ることは、場→波→縁の活動の一部を捉える

#### `[独自]`

- [独自] 測定対象を“アイデア数”ではなく“欠損の保持と変換”へ拡張する提案

#### `[学び]`

- [学び] 実証研究へ接続するための操作概念・指標の整備

#### `[文脈]`

- [文脈] 教育評価。創造性＝能力として測り、育成する系譜

---

## EV-CR-014: 表象変化（Representational Change）と洞察

- **layer**: [P+M]
- **claims**:
  - [P] 洞察（insight）は、問題表象の再編（制約の緩和、再符号化など）で生じる
  - [M] 表象変化は「波」（対立/詰まり）から「縁/渦」（再構成）へのジャンプに対応
- **supports**: D2（意味の欠損）, M1/M2（モデル更新）
- **module**: M1, M2
- **refs**:
  - Ohlsson, S. (1992). Information-processing explanations of insight and related phenomena. In *Advances in the Psychology of Thinking*.（要検証: 書誌）
  - Ohlsson, S. (2011). *Deep Learning: How the Mind Overrides Experience*. Cambridge University Press.
- **used_in**: Phase 6（洞察の理論補強）

#### `[類似]`

- [類似] “詰まり”からの脱出は、表象（予測モデル）の変化として起きる

#### `[独自]`

- [独自] 表象変化を、欠損（D2）とWithhold（D3）の循環として説明し、情動（F-O）を組み込む

#### `[学び]`

- [学び] 制約緩和・再符号化など、洞察の“手続き語彙”

#### `[文脈]`

- [文脈] 認知心理学の洞察研究。タスク依存の精密記述

---

## EV-CR-015: Dual Pathway to Creativity（柔軟性経路 / 持続性経路）

- **layer**: [P+M]
- **claims**:
  - [P] 創造的産出は「柔軟性（flexibility）」と「持続性（persistence）」という2経路で高まる
  - [M] 柔軟性＝場/波での拡散、持続性＝Withholdを保った探索の継続（渦）
- **supports**: D3（保持の持続性）, D4（動機/情動）, M2
- **module**: M2, Layer 2-3
- **refs**:
  - De Dreu, C. K. W., Baas, M., & Nijstad, B. A. (2008). Hedonic tone and activation level in the mood–creativity link. *Journal of Personality and Social Psychology*.（要検証: 書誌）
  - Nijstad, B. A., De Dreu, C. K. W., Rietzschel, E. F., & Baas, M. (2010). The dual pathway to creativity model: Creative ideation as a function of flexibility and persistence. *European Review of Social Psychology*.（要検証: 書誌）
- **used_in**: Phase 6（動機×探索様式の補強）

#### `[類似]`

- [類似] “発散だけではない”＝持続的探索（渦）の重要性

#### `[独自]`

- [独自] 持続性を「欠損を問いとして保持する力（Withhold）」として定義し直す

#### `[学び]`

- [学び] 柔軟性/持続性という2軸で、創造プロセスの失敗モードを分類できる

#### `[文脈]`

- [文脈] 社会心理学（気分・動機）系。個人内の経路差に焦点

---

## EV-CR-016: 神経科学（Default Network × Executive Control の協調）

- **layer**: [P+M]
- **claims**:
  - [P] 創造的課題では、デフォルトモードネットワーク（DMN）と実行制御ネットワーク（ECN）の協調が観察される
  - [M] DMN（連想/内省）× ECN（制御/評価）の協調は、波→縁→渦の往復運動の神経基盤候補
- **supports**: 4層モデル（L1-L3）, D3（保持と制御）
- **module**: M1, M2
- **refs**:
  - Beaty, R. E., Benedek, M., Silvia, P. J., & Schacter, D. L. (2016). Creative cognition and brain network dynamics. *Trends in Cognitive Sciences*.（要検証: 書誌）
  - Beaty, R. E., et al. (2015). Default and executive network coupling supports creative idea production.（要検証: 書誌）
- **used_in**: Phase 6（神経科学的補強）

#### `[類似]`

- [類似] “連想（場/縁）”と“制御（束/評価）”の同時作動が創造に必要

#### `[独自]`

- [独自] ネットワーク協調を、欠損（D2）→F-O評価（D4）→Withhold（D3）の層間循環に位置づける

#### `[学び]`

- [学び] Withholdの神経指標候補（DMN-ECN協調）を設定できる

#### `[文脈]`

- [文脈] 認知神経科学。課題設計と指標（機能結合）中心

---

## EV-CR-017: Creative Problem Solving（CPS: Osborn–Parnes）

- **layer**: [P+M]
- **claims**:
  - [P] 発散→収束の手順としてのCPS（問題把握、アイデア生成、解決策開発、実装 等）
  - [M] 5段階を実務プロセスへ翻訳する足場（場→波→縁→渦→束を運用語彙に落とす）
- **supports**: OPS（運用手順化）, M2（プロセスの実装）
- **module**: M2
- **refs**:
  - Osborn, A. F. (1953). *Applied Imagination*. Scribner.
  - Parnes, S. J. (1967). *Creative Behavior Guidebook*. Scribner.（要検証: 書誌）
- **used_in**: 運用設計（導入・ワークショップ）

#### `[類似]`

- [類似] 発散→収束をプロセスとして設計する

#### `[独自]`

- [独自] “問題解決”ではなく“欠損の保持（Withhold）”をコアに置き、反射的収束を避ける

#### `[学び]`

- [学び] 手順化・ワーク設計のノウハウ（実務実装への翻訳）

#### `[文脈]`

- [文脈] 企業研修・教育の方法論。科学理論というより実践手続き

---

## EV-CR-018: 社会文化的枠組み（5A: Actor/Action/Artifact/Audience/Affordances）

- **layer**: [P+M]
- **claims**:
  - [P] 創造性は「個人の能力」ではなく、行為・産物・受け手・環境の関係の中に分配される
  - [P] 5Aは、創造を Actor / Action / Artifact / Audience / Affordances に分解する
  - [M] Audience（受け手）とAffordances（環境の可能性）はM3/M4を強く要求する
- **supports**: M3（受け手・評価）, M4（環境・規範）, OPS（粒度管理）
- **module**: M3, M4
- **refs**:
  - Glăveanu, V. P. (2013). Rewriting the language of creativity: The Five A's framework. *Review of General Psychology*.（要検証: 書誌）
  - Glăveanu, V. P. (2014). *Distributed Creativity: Thinking Outside the Box of the Creative Individual*. Springer.
- **used_in**: Phase 6（社会文化的補強）

#### `[類似]`

- [類似] 創造は個人内で完結しない（M3/M4の必然）

#### `[独自]`

- [独自] “分配された創造”を、欠損（共有される欠損）とWithhold（集団的保持）として再記述する

#### `[学び]`

- [学び] Audience/評価/環境の語彙を精密にし、M3の設計論へ接続できる

#### `[文脈]`

- [文脈] 社会文化心理学。創造の定義を個人から関係へ移す立場

---

## クロスリファレンス

### 表A: EV-CR（18理論）俯瞰

| 理論ID | 理論（短） | 主焦点（目安） | 主モジュール | 一言フック |
|------|-----------|----------------|------------|-----------|
| 001 | Wallas 4段階 | 場→束（段階） | M2 | 古典的段階モデル |
| 002 | Guilford 発散/収束 | 場→束（二相） | M2 | 発散↔収束 |
| 003 | Csik フロー/システム | 個人×領域×場 | M1-4 | 評価システム込み |
| 004 | Amabile 構成要素 | Layer2（動機） | M2 | 動機×スキル×プロセス |
| 005 | Sawyer 協調創造 | 縁→束（集団） | M3 | グループフロー |
| 006 | Boden 計算論 | 場→渦（探索/変換） | M2 | AI対比の足場 |
| 007 | Rhodes 4P | 分解枠（整理） | M1-4 | 議論の混線防止 |
| 008 | Mednick RAT | 縁（連想） | M2 | 遠隔連想を測る |
| 009 | Geneplore | 波↔縁（往復） | M2 | 生成→探索 |
| 010 | BVSR | 探索↔選択 | M2 | 変異と淘汰 |
| 011 | 投資理論 | 束（価値化） | M3-4 | 安く買って高く売る |
| 012 | 4C | 評価スケール | M3 | mini-c〜Big-C |
| 013 | Torrance/TTCT | 測定（発散） | M2 | 発散を測る |
| 014 | 表象変化 | 波→縁/渦 | M1-2 | 洞察＝再表象 |
| 015 | Dual Pathway | 柔軟/持続 | M2 | 2経路モデル |
| 016 | DMN×ECN | L1-L3（協調） | M1-2 | 連想×制御 |
| 017 | CPS | 場→束（手順） | M2 | 発散→収束の実装 |
| 018 | 5A | 受け手/環境 | M3-4 | 分配された創造 |

### 表B: 欠損駆動思考の独自的貢献（先行研究との差異）

| 先行研究の課題 | 欠損駆動思考による解決（方針） | 関連論拠 |
|-------------|------------------------------|---------|
| 段階の内部構造が不明 | 5段階 + 4層で内部機構（欠損/Withhold/F-O）を記述 | D1-D4, EV-NS-* |
| 主観的経験の記述不足 | 「欠損（D2）」を起点にし、問題概念を経験側から定義 | D2 |
| 動機の内部構造不明 | F-O評価軸で動機を分解し、創造性阻害を失敗モード化 | D4, EV-CR-004 |
| 社会文化的次元が弱い | M3/M4を必須化し、評価・受容・環境をモデルに含める | EV-CR-003, EV-CR-011, EV-CR-018 |
| 実証接続の弱さ | 測定（TTCT/RAT/ネットワーク指標）を足場に、検証可能仮説を設計 | EV-CR-008, EV-CR-013, EV-CR-016 |
| AI対比の根拠が薄い | 「計算」ではなく「経験（欠損）」を弁別点に置く | EV-CR-006 |
