---
file_id: EV-LS
domain: life-sciences
last_updated: 2026-02-06
entry_count: 11
sync_target: Project Knowledge（変更時のみ）
---

# 論拠DB：生命科学（Life Sciences）

**目的**: 4層モデル（D1-D4）を支える生化学・代謝・細胞生物学的論拠の集積。
**位置づけ**: EV-NS（情報処理としての脳）と相補的。エネルギー・代謝としての脳を記述。
**出発点**: pjdhiro提示のBSPLモデル（S19, S20）からの着想。ただし下記注記を参照。

> **⚠️ BSPLモデルの位置づけに関する注記**
>
> EV-LSの各エントリはBSPLモデルとの対応（bsplフィールド）を含むが、
> **EV-LSの主たる接続先は4層モデル（D1-D4）である**。
> BSPLは探索的補助モデル（[S], L1）であり、本論の中核ではない。
> bsplフィールドは「BSPLの視点で読むとこう見える」という補助的注釈であり、
> EV-LSエントリの学術的妥当性はBSPLに依存しない。
> 詳細: `base/schema/auxiliary/bspl-model.md` §1（位置づけ）

**凡例**: [P] 実験的事実・確立理論 / [M] 理論から着想した解釈 / [S] 検証可能な仮説

**EV-NSとの境界**:
- EV-NS = 情報処理（ニューロン中心、予測符号化、実行機能、意識）
- EV-LS = エネルギー・代謝（グリア、ミトコンドリア、代謝、免疫、恒常性）
- 境界例：予測符号化のprecision調整にアストロサイトが関与する場合 → EV-LS

**サブ分野**:
| ID | 名称 | 主な対象 |
|----|------|---------|
| LS-A | グリア生物学 | アストロサイト、ミクログリア、オリゴデンドロサイト |
| LS-B | 神経代謝学 | ラクテートシャトル、グリコーゲン、ATP |
| LS-C | ミトコンドリア生物学 | mtCB1、ミトコンドリア機能、酸化ストレス |
| LS-D | エンドカンナビノイド系 | CB1/CB2受容体、2-AG、AEA |
| LS-E | 神経免疫学 | ミクログリア活性化、サイトカイン、神経炎症 |
| LS-F | ミエリン可塑性 | 経験依存的ミエリン化、白質発達 |
| LS-G | アロスタシス/恒常性 | アロスタティック負荷、ストレス応答 |
| LS-H | 睡眠・回復科学 | グリンパティック系、睡眠負債 |

---

## EV-LS-001: アストロサイト-ニューロン・ラクテートシャトル

- **layer**: [P+M]
- **sub_field**: LS-A, LS-B
- **claims**:
  - [P] アストロサイトはグルタミン酸取り込みに連動して好気的解糖を亢進し、乳酸を産生・放出する（ANLS仮説）
  - [P] 乳酸はモノカルボン酸トランスポーター（MCT1/4: アストロサイト、MCT2: ニューロン）を介して細胞間輸送される
  - [P] 海馬における乳酸輸送の阻害は長期記憶形成を障害するが、短期記憶には影響しない
  - [P] アストロサイトのグリコーゲン分解による乳酸放出は長期増強（LTP）の維持に必要
  - [P] ANLS仮説には批判もあり、ニューロン自身の解糖能力を示す反証的データが存在する（Dienel, 2017; Diaz-Garcia et al., 2017）
  - [M] アストロサイトによるエネルギー供給は、BionのContainer-Contained概念の生物学的相同体と読める——「問いを保持する」ための代謝的基盤を他者（アストロサイト）が提供する
  - [S] BSPLモデルにおける「資産: 代謝バッファ」はアストロサイトのグリコーゲン備蓄に対応する
- **supports**: D3（Withholdの代謝的前提条件）, D2（欠損を保持するためのエネルギーコスト）, E10（安定した関係＝Container）
- **4layer**: Layer 3 の代謝的基盤。Withholdは「問いとして保持する」ためにエネルギーを消費し、そのエネルギーをアストロサイトが供給する
- **bspl**: BS資産（グリコーゲン/代謝バッファ）、PL収益（学習収益＝乳酸によるLTP維持）
- **refs**:
  - Pellerin, L., & Magistretti, P. J. (1994). Glutamate uptake into astrocytes stimulates aerobic glycolysis. *PNAS*, 91(22), 10625-10629.
  - Pellerin, L., et al. (1998). Evidence supporting the existence of an activity-dependent astrocyte-neuron lactate shuttle. *Dev Neurosci*, 20(4-5), 291-299.
  - Suzuki, A., et al. (2011). Astrocyte-neuron lactate transport is required for long-term memory formation. *Cell*, 144(5), 810-823.
  - Magistretti, P. J., & Allaman, I. (2015). A cellular perspective on brain energy metabolism and functional imaging. *Neuron*, 86(4), 883-901.
  - Dienel, G. A. (2017). Lack of appropriate stoichiometry: Strong evidence against an energetically important astrocyte-neuron lactate shuttle in brain. *J Neurosci Res*, 95(11), 2103-2125.
  - Diaz-Garcia, C. M., et al. (2017). Neuronal stimulation triggers neuronal glycolysis and not lactate uptake. *Cell Metab*, 26(2), 361-374.
  - Bélanger, M., Allaman, I., & Magistretti, P. J. (2011). Brain energy metabolism: Focus on astrocyte-neuron metabolic cooperation. *Cell Metab*, 14(6), 724-738.
- **used_in**: ISS-37（BSPL深掘り）, LOG-20260206-002
- **notes**: ANLS仮説は20年超の論争を経ており、完全な合意には至っていない。記憶形成における乳酸輸送の必要性（Suzuki et al., 2011）は強いエビデンスだが、定量的ストイキオメトリの問題が残る。本論では「アストロサイトのエネルギー供給」という機能的事実を用い、シャトルの詳細メカニズムへのコミットは避ける。

---

## EV-LS-002: 三者間シナプス（Tripartite Synapse）

- **layer**: [P+M]
- **sub_field**: LS-A
- **claims**:
  - [P] シナプスはプレ・ポスト・アストロサイトの3要素からなる（tripartite synapse概念）
  - [P] アストロサイトはシナプス活動に応答してCa²⁺シグナルを発生し、グリオトランスミッター（グルタミン酸、D-セリン、ATP）を放出する
  - [P] アストロサイトのグリオトランスミッション（D-セリン放出等）がシナプス可塑性（LTPのNMDA受容体共活性化）を調節する
  - [P] 単一アストロサイトが数万〜数十万のシナプスに接触し、広域的なネットワーク統合を行う
  - [P] 成熟脳ではmGluR5発現が消失するとの報告があり、tripartite synapse概念の適用範囲に論争がある（Sun et al., 2013; Nedergaard批判）
  - [M] アストロサイトの時間スケール（秒〜十秒）はニューロンの高速伝達（ミリ秒）と異なり、「遅い統合」を担う——これはWithhold（即座に解決しない保持）の時間的基盤に対応する
  - [S] アストロサイトのCa²⁺マイクロドメインがシナプスレベルでprecision weightingの代謝的調節を担う
- **supports**: D3（Withholdの時間スケール）, D1（誤差を問いとして拾う＝アストロサイトの遅い統合）
- **4layer**: Layer 1-3 横断。Layer 1 のprecision調整の代謝的裏付け、Layer 3 の時間的基盤
- **bspl**: 横断的——アストロサイトはBS/PL全体の「会計システム」を運営する主体
- **refs**:
  - Araque, A., Parpura, V., Sanzgiri, R. P., & Haydon, P. G. (1999). Tripartite synapses: glia, the unacknowledged partner. *Trends Neurosci*, 22(5), 208-215.
  - Perea, G., Navarrete, M., & Araque, A. (2009). Tripartite synapses: astrocytes process and control synaptic information. *Trends Neurosci*, 32(8), 421-431.
  - Halassa, M. M., Fellin, T., & Haydon, P. G. (2007). The tripartite synapse: roles for gliotransmission in health and disease. *Trends Mol Med*, 13(2), 54-63.
  - Henneberger, C., Papouin, T., Bhatt, D. K., & Bhatt, D. J. (2010). Long-term potentiation depends on release of D-serine from astrocytes. *Nature*, 463(7278), 232-236.
  - Arizono, M., et al. (2020). Structural basis of astrocytic Ca²⁺ signals at tripartite synapses. *Nat Commun*, 11(1), 1906.
  - Sun, W., et al. (2013). Glutamate-dependent neuroglial calcium signaling differs between young and adult brain. *Science*, 339(6116), 197-200.
  - Araque, A., et al. (2014). Gliotransmitters travel in time and space. *Neuron*, 81(4), 728-739.
- **used_in**: ISS-37（BSPL深掘り）, LOG-20260206-002
- **notes**: tripartite synapse概念は1999年以来の蓄積があるが、成熟脳での適用範囲に論争が残る。mGluR5消失問題は重要な反証。本論では「アストロサイトがシナプスの第三要素である」という構造的事実と「遅い時間スケールでの統合」を用い、メカニズムの詳細（Ca²⁺シグナル経路）への過度なコミットは避ける。

---

## EV-LS-003: mtCB1受容体とミトコンドリア代謝調節

- **layer**: [P+M]
- **sub_field**: LS-C, LS-D
- **claims**:
  - [P] CB1受容体はニューロンのミトコンドリア外膜に存在する（mtCB1, 全CB1の約10-15%）
  - [P] mtCB1の活性化はミトコンドリア内cAMP→PKA→複合体I活性の低下→細胞呼吸抑制を引き起こす
  - [P] mtCB1を介したミトコンドリアエネルギー代謝の調節は海馬における記憶形成に直接関与する
  - [P] 内因性カンナビノイド（2-AG等）がmtCB1を活性化し、脱分極誘導抑制（DSI）のミトコンドリア的機序に寄与する
  - [P] mtCB1の存在については方法論的論争があったが、適切な精製・対照実験により確認されている（Hebert-Chatelain et al., 2014）
  - [M] mtCB1はBSPLモデルの「中央: 予算ノブ」に対応する——代謝出力の上限を調節するゲインコントロール
  - [S] mtCB1による代謝調節は、Withholdの持続時間（どれだけ長く問いを保持できるか）の物理的上限を規定する
- **supports**: D3（Withholdの物理的制約）, D2（欠損保持のエネルギーコスト）
- **4layer**: Layer 3 のエネルギー的制約。Withholdは代謝的に「高コスト」であり、mtCB1がその予算を調整する
- **bspl**: BS資産（ミトコンドリア能力）、PL中央（mtCB1予算ノブ）
- **refs**:
  - Bénard, G., et al. (2012). Mitochondrial CB1 receptors regulate neuronal energy metabolism. *Nat Neurosci*, 15(4), 558-564.
  - Hebert-Chatelain, E., et al. (2016). A cannabinoid link between mitochondria and memory. *Nature*, 539(7630), 555-559.
  - Hebert-Chatelain, E., et al. (2014). Cannabinoid control of brain bioenergetics: Exploring the subcellular localization of the CB1 receptor. *Mol Cell Endocrinol*, 397(1-2), 4-11.
  - Marsicano, G., et al. (2003). CB1 cannabinoid receptors and on-demand defense against excitotoxicity. *Science*, 302(5642), 84-88.
  - Koch, M., et al. (2015). Hypothalamic POMC neurons promote cannabinoid-induced feeding. *Nature*, 519(7541), 45-50.
  - Picard, M., & McEwen, B. S. (2018). Psychological stress and mitochondria: A systematic review. *Psychosom Med*, 80(2), 141-153.
- **used_in**: ISS-37（BSPL深掘り）, LOG-20260206-002, S19
- **notes**: mtCB1研究はMarsicano研究室が牽引しており、独立的追試がまだ限定的。方法論的論争は解決済みとされるが、フィールドとしては若い。本論ではmtCB1を「代謝調節の具体例」として用い、BSPLの「予算ノブ」メタファーの生物学的裏付けとする。mtCB1固有のメカニズムに理論全体を依存させない。

---

## EV-LS-004: ミクログリアのシナプス刈り込みと神経炎症

- **layer**: [P+M]
- **sub_field**: LS-A, LS-E
- **claims**:
  - [P] ミクログリアは脳の常在免疫細胞であり、シナプスの監視・刈り込みを行う
  - [P] 発達期のシナプス刈り込みは補体系（C1q, C3）を介したミクログリア貪食によって行われる
  - [P] ミクログリアの過活性化は神経炎症を引き起こし、サイトカイン（IL-1β, TNF-α, IL-6）の過剰放出につながる
  - [P] 慢性的な神経炎症はシナプス可塑性を障害し、認知機能低下と関連する
  - [P] ミクログリアは活性化状態に応じて多様な表現型をとる（M1/M2分極の単純な二分法は批判されている）
  - [M] ミクログリアの刈り込みは「予測誤差の物理的削除」——使われなくなった予測モデル（シナプス）を除去するプロセス
  - [M] 神経炎症はBSPLの「負債」に対応——処理されなかったストレスの代謝的蓄積
  - [S] ミクログリアの過活性化（負債増大）はWithhold容量を低下させ、創造的思考を阻害する
- **supports**: D2（欠損の物理的基盤——シナプスレベルでの予測モデル変更）, D3（Withholdの阻害要因）
- **4layer**: Layer 1（予測モデルの更新・削除）、Layer 3（Withhold阻害）
- **bspl**: BS負債（炎症・未処理ストレス）
- **refs**:
  - Schafer, D. P., et al. (2012). Microglia sculpt postnatal neural circuits in an activity and complement-dependent manner. *Neuron*, 74(4), 691-705.
  - Stevens, B., et al. (2007). The classical complement cascade mediates CNS synapse elimination. *Cell*, 131(6), 1164-1178.
  - Salter, M. W., & Stevens, B. (2017). Microglia emerge as central players in brain disease. *Nat Med*, 23(9), 1018-1027.
  - Dantzer, R., et al. (2008). From inflammation to sickness and depression: when the immune system subjugates the brain. *Nat Rev Neurosci*, 9(1), 46-56.
  - Ransohoff, R. M. (2016). A polarizing question: do M1 and M2 microglia exist? *Nat Neurosci*, 19(8), 987-991.
  - Hong, S., et al. (2016). Complement and microglia mediate early synapse loss in Alzheimer mouse models. *Science*, 352(6286), 712-716.
- **used_in**: ISS-37（BSPL深掘り）, LOG-20260206-002
- **notes**: M1/M2分極モデルは過度に単純化されており（Ransohoff, 2016）、ミクログリアの多様な状態を反映しない。本論では「刈り込み」と「炎症」という機能的役割を使用し、分極モデルへのコミットは避ける。

---

## EV-LS-005: 経験依存的ミエリン化

- **layer**: [P+M]
- **sub_field**: LS-F
- **claims**:
  - [P] ミエリン形成は発達期に限らず、成人脳でも経験・学習に応じて継続する（適応的ミエリン化）
  - [P] オリゴデンドロサイト前駆細胞（OPC）は成人脳にも存在し、活動依存的にミエリン化を促進する
  - [P] 新たなスキル学習（ピアノ演奏、ジャグリング等）は白質構造の変化と相関する
  - [P] ミエリン化は神経伝導速度を上昇させ、回路の時間的同期（タイミング精度）を改善する
  - [M] 「問いとして保持した」結果としてよく使われた神経経路がミエリン化される——これはWithholdの長期的成果の物理的記録
  - [M] ミエリン化はCN-001（内在化された関係）の生物学的裏付け——繰り返し活性化された関係性のパターンが物理的に「太く」なる
  - [S] BSPLモデルの「資産: 可塑性資本」はミエリン化の蓄積に対応する
- **supports**: D3（Withholdの長期的成果）, CN-001（内在化された関係）
- **4layer**: Layer 1-3 横断。予測モデル（Layer 1）の物理的強化、Withhold（Layer 3）の長期的結果
- **bspl**: BS資産（可塑性資本）、PL収益（学習収益の物理的蓄積）
- **refs**:
  - Fields, R. D. (2015). A new mechanism of nervous system plasticity: activity-dependent myelination. *Nat Rev Neurosci*, 16(12), 756-767.
  - McKenzie, I. A., et al. (2014). Motor skill learning requires active central myelination. *Science*, 346(6207), 318-322.
  - Scholz, J., Klein, M. C., Behrens, T. E., & Johansen-Berg, H. (2009). Training induces changes in white-matter architecture. *Nat Neurosci*, 12(11), 1370-1371.
  - Gibson, E. M., et al. (2014). Neuronal activity promotes oligodendrogenesis and adaptive myelination in the mammalian brain. *Science*, 344(6183), 1252304.
  - Bengtsson, S. L., et al. (2005). Extensive piano practicing has regionally specific effects on white matter development. *Nat Neurosci*, 8(9), 1148-1150.
  - Mount, C. W., & Bhatt, D. K. (2019). Wrapped to adapt: experience-dependent myelination. *Neuron*, 95(4), 743-756.
- **used_in**: ISS-37（BSPL深掘り）, LOG-20260206-002, CN-001
- **notes**: 経験依存的ミエリン化は比較的新しい分野（2014年〜）で急速に発展中。ヒトでのエビデンスはDTI等の間接的計測が中心であり、因果関係の確立にはさらなる研究が必要。本論では「使用される回路の物理的強化」という現象レベルで用い、メカニズムの詳細への過度な依存は避ける。

---

## EV-LS-006: アロスタティック負荷モデル

- **layer**: [P+M]
- **sub_field**: LS-G
- **claims**:
  - [P] アロスタシスは変化を通じて安定性を維持するプロセス（ホメオスタシスの拡張概念）
  - [P] アロスタティック負荷は適応反応の慢性的累積コストであり、HPA軸の持続的活性化、コルチゾール調節不全等として現れる
  - [P] 慢性ストレスは海馬の樹状突起萎縮、前頭前野の構造変化を引き起こす
  - [P] アロスタティック過負荷は心血管疾患、免疫機能低下、認知機能低下と関連する
  - [M] アロスタティック負荷はBSPLの「負債: 未処理ストレス」——予測誤差が適切に処理されず蓄積した状態の代謝的コスト
  - [M] Withholdの失敗（誤差を即座に処理するか、完全に抑圧するか）がアロスタティック負荷の蓄積につながる
  - [S] 適切なWithhold（問いとして保持し、やがて統合する）はアロスタティック負荷を軽減する——欠損駆動思考は健康的なストレス処理モデルでもある
- **supports**: D3（Withholdの失敗の帰結）, D2（欠損の蓄積コスト）
- **4layer**: Layer 3 の失敗モード。Withholdが機能しない場合のシステムレベルの帰結
- **bspl**: BS負債（未処理ストレス）、純資産（レジリエンス）の低下
- **refs**:
  - McEwen, B. S. (1998). Protective and damaging effects of stress mediators. *NEJM*, 338(3), 171-179.
  - McEwen, B. S. (2007). Physiology and neurobiology of stress and adaptation: Central role of the brain. *Physiol Rev*, 87(3), 873-904.
  - McEwen, B. S., & Gianaros, P. J. (2010). Central role of the brain in stress and adaptation: Links to socioeconomic status, health, and disease. *Ann NY Acad Sci*, 1186, 190-222.
  - Juster, R. P., McEwen, B. S., & Lupien, S. J. (2010). Allostatic load biomarkers of chronic stress and impact on health and cognition. *Neurosci Biobehav Rev*, 35(1), 2-16.
  - Picard, M., & McEwen, B. S. (2018). Psychological stress and mitochondria: A systematic review. *Psychosom Med*, 80(2), 141-153.
  - Lupien, S. J., et al. (2009). Effects of stress throughout the lifespan on the brain, behaviour and cognition. *Nat Rev Neurosci*, 10(6), 434-445.
- **used_in**: ISS-37（BSPL深掘り）, LOG-20260206-002
- **notes**: McEwenのアロスタシスモデルは広く受容されているが、「アロスタティック負荷」の測定方法は標準化されていない。本論では概念的枠組みとして使用し、具体的なバイオマーカーへのコミットは避ける。Picard & McEwen (2018)によるストレスとミトコンドリアの系統的レビューがEV-LS-003との接点を提供。

---

## EV-LS-007: グリンパティック系と睡眠負債

- **layer**: [P+M]
- **sub_field**: LS-H
- **claims**:
  - [P] グリンパティック系はアストロサイトのAQP4水チャネルを介した脳実質の老廃物排出システムである
  - [P] グリンパティック系は主に睡眠中に活性化し、覚醒時と比較して間質腔が60%拡大する
  - [P] アミロイドβ等の代謝老廃物はグリンパティック系を通じて排出される
  - [P] 睡眠不足はグリンパティック系の機能低下を招き、老廃物の蓄積につながる
  - [P] 慢性的睡眠不足は認知機能低下、情動調節障害、長期的な神経変性リスクと関連する
  - [M] 睡眠はBSPLにおける「負債の返済プロセス」——覚醒中に蓄積した代謝老廃物（負債）を睡眠中に清算する
  - [M] グリンパティック系の機能は「夜間の帳簿整理」——BSの負債を減らし、翌日のWithhold容量を回復する
  - [S] 適切な睡眠はWithhold容量の回復に直接寄与し、睡眠負債はWithhold容量を低下させる
- **supports**: D3（Withholdの回復条件）, D2（欠損保持の代謝コストの清算）
- **4layer**: Layer 0-3 横断。全Layer の機能回復・代謝的リセット
- **bspl**: BS負債（睡眠負債）、PL収益（休息収益＝グリンパティック排出）
- **refs**:
  - Xie, L., et al. (2013). Sleep drives metabolite clearance from the adult brain. *Science*, 342(6156), 373-377.
  - Iliff, J. J., et al. (2012). A paravascular pathway facilitates CSF flow through the brain parenchyma and the clearance of interstitial solutes, including amyloid β. *Sci Transl Med*, 4(147), 147ra111.
  - Nedergaard, M. (2013). Garbage truck of the brain. *Science*, 340(6140), 1529-1530.
  - Walker, M. P. (2017). *Why We Sleep*. Scribner.
  - Fultz, N. E., et al. (2019). Coupled electrophysiological, hemodynamic, and cerebrospinal fluid oscillations in human sleep. *Science*, 366(6465), 628-631.
  - Mander, B. A., Winer, J. R., & Walker, M. P. (2017). Sleep and human aging. *Neuron*, 94(1), 19-36.
- **used_in**: ISS-37（BSPL深掘り）, LOG-20260206-002
- **notes**: グリンパティック系は2012年発見の比較的新しい知見。ヒトでの直接的エビデンスは限定的（動物実験が中心）だが、Fultz et al. (2019)によるヒト睡眠中のCSF流動の直接計測が重要な追試となっている。「60%間質腔拡大」の知見は麻酔下マウスの結果であり、自然睡眠への一般化には慎重さが必要。

---

## EV-LS-008: 神経信号のエネルギーコスト

- **layer**: [P+M]
- **sub_field**: LS-B
- **claims**:
  - [P] 灰白質における神経信号伝達のエネルギー消費は、主としてNa⁺/K⁺-ATPaseによるイオン勾配回復（活動電位・シナプス後電流など）に費やされる
  - [P] 灰白質の信号伝達コストの内訳推定では、活動電位とシナプス後電流が主要な寄与を占め、静止電位維持や前シナプス過程も一定の割合で寄与する
  - [P] 発火頻度やシナプス活動の増加はATP需要を増大させ、局所血流・酸素/グルコース利用の増加（神経血管・代謝結合）として観測される
  - [P] エネルギー制約（酸素/グルコース供給・発熱・ミトコンドリア能力など）は、皮質計算がスパースであることの一因として議論されている
  - [P] その後のモデル更新により、領域（新皮質/小脳）や仮定（シナプス放出確率、スパイン密度、伝導速度など）に依存して各項目の寄与割合は変動しうることが示されている
  - [M] 神経信号のエネルギー予算は、Withhold（D3）に伴う『保持コスト』の下限を与える——問いを保持するとは神経活動の状態を一定時間維持/調整することであり、そのたびにATP支出が発生する
  - [M] エネルギー制約がスパース性を要請するという観察は、D1の『棄却される誤差』の物理的背景にもなる——すべての誤差を同時に拾えない以上、何を問いとして拾うかは代謝予算により選別される
- **supports**: D2（欠損保持のエネルギーコスト）, D3（Withholdのコスト構造）, E06（すぐに解決しないことの条件＝費用の受容）
- **4layer**: Layer 0-3 横断の費用基盤。Layer 1-3 の処理/保持は神経信号のATPコストに支えられ、代謝予算がWithholdの上限を規定する
- **bspl**: PL費用（入力コスト＝神経信号のATPコスト）、PL費用（保持コスト＝状態維持の代謝支出）
- **refs**:
  - Attwell, D., & Laughlin, S. B. (2001). An energy budget for signaling in the grey matter of the brain. *J Cereb Blood Flow Metab*, 21(10), 1133-1145.
  - Lennie, P. (2003). The cost of cortical computation. *Curr Biol*, 13(6), 493-497.
  - Howarth, C., Gleeson, P., & Attwell, D. (2012). Updated energy budgets for neural computation in the neocortex and cerebellum. *J Cereb Blood Flow Metab*, 32(7), 1222-1232.
  - Harris, J. J., Jolivet, R., & Attwell, D. (2012). Synaptic energy use and supply. *Neuron*, 75(5), 762-777.
- **used_in**: ISS-37（BSPL深掘り）, LOG-20260206-002
- **notes**: エネルギー予算は推定モデル（形態学的パラメータ、発火率、放出確率など）に依存し、定量値は研究間で揺れる。基礎となる比率を「固定値」として扱わず、範囲/条件依存として引用する。

---

## EV-LS-009: 報酬予測誤差のドーパミン系

- **layer**: [P+M]
- **sub_field**: LS-B
- **claims**:
  - [P] 中脳ドーパミンニューロン（例: SNc/VTA）は、予期しない報酬提示に対して短潜時の一過性興奮（phasic burst）を示すことが報告されている
  - [P] 条件づけ学習後には、ドーパミンニューロンの一過性応答が「報酬そのもの」から「報酬を予告する刺激」へ移行しうる
  - [P] 予告された報酬が期待どおり提示された場合、報酬提示時の一過性応答は減弱/消失し、逆に期待された報酬が欠如した場合には報酬提示時刻付近で活動低下（phasic dip）が観察される
  - [P] 報酬確率や価値の操作により、ドーパミンニューロンの一過性応答が段階的に変化することが報告されている
  - [P] ドーパミン系は線条体などへ広範に投射し、受容体（例: D1/D2）を介してシナプス可塑性や回路状態を調節しうる
  - [M][DRAFT] 期待された報酬が欠如した際のphasic dipは、欠損（D2）が『欠け』として立ち上がる瞬間の神経化学的フックになりうる——期待の未達を『差分』として刻むことで、次の保持/更新の前提条件を与える
  - [M][DRAFT] ドーパミンのphasic応答は、予測-誤差ループ（Layer 1）における「帳簿上の差異」を回路に書き込むための生化学的コストとして読める——burst/dipの度にD1/D2受容体を介したシナプス可塑性が駆動され、予測モデルの更新にATPが消費される
- **supports**: D2（欠損＝予想と現実の差分の生化学的フック）, D1（棄却される誤差を問いとして拾う——phasic dipが拾うべき誤差の存在を神経化学的に示す）
- **4layer**: Layer 1 の予測-誤差ループにおける差分シグナルの候補。欠損が『問い』として立ち上がる入口（D1/D2）を神経化学的に裏打ちする
- **bspl**: PL費用（切替コスト＝予測モデル更新のドーパミン系コスト）[DRAFT] <!-- UNCERTAIN残: tonic dopamineのBS側対応は未整理。EV-NS側との完全な整合はBSPL R2で -->
- **refs**:
  - Schultz, W., Dayan, P., & Montague, P. R. (1997). A neural substrate of prediction and reward. *Science*, 275(5306), 1593-1599.
  - Hollerman, J. R., & Schultz, W. (1998). Dopamine neurons report an error in the temporal prediction of reward during learning. *Nat Neurosci*, 1(4), 304-309.
  - Schultz, W. (1998). Predictive reward signal of dopamine neurons. *J Neurophysiol*, 80(1), 1-27.
  - Fiorillo, C. D., Tobler, P. N., & Schultz, W. (2003). Discrete coding of reward probability and uncertainty by dopamine neurons. *Science*, 299(5614), 1898-1902.
- **used_in**: ISS-37（BSPL深掘り）, LOG-20260206-002
- **notes**: ドーパミン応答は一様ではなく、サリエンス/新奇性/運動などの要因で応答様式が異なる集団もある。EV-LSでは神経化学的・生理学的事実に留め、計算論（予測符号化/強化学習）の接続はEV-NS側で整理する。

---

## EV-LS-010: 呼吸の自律神経効果

- **layer**: [P+M+S]
- **sub_field**: LS-G
- **claims**:
  - [P] 呼吸速度を意図的に低下させる（例: 約6呼吸/分の0.1 Hz近傍）と、呼吸性洞性不整脈（RSA）や心拍変動（HRV）が増大しうることが報告されている
  - [P] 遅い呼吸は圧受容体反射（baroreflex）感受性の増大や、血圧・心拍の変動パターンの変化と関連づけられている
  - [P] 慢性心不全患者を対象とした研究で、遅い呼吸が動脈圧受容体反射感受性を増大させることが報告されている
  - [P] 本態性高血圧患者を対象とした研究で、遅い呼吸訓練が圧受容体反射感受性の増大と血圧低下に関連することが報告されている
  - [P] HRVバイオフィードバック（共鳴周波数呼吸を用いる訓練）は、HRV増加や圧受容体反射ゲイン増大と関連する報告がある
  - [M] 遅い呼吸はLayer 0（内受容）の時間スケールを意図的に変えることで、Layer 3（Withhold）を支える身体的技法になりうる——反射的な即応を一度保留し、『待てる身体』を作る
  - [M] 呼吸は『身体は最初の問いである』（E07）の最小単位の実装——身体入力（Layer 0）を整えることで、欠損（D2）の立ち上がり方と保持（D3）が変わりうる
  - [S] 共鳴周波数呼吸（個人の0.1 Hz近傍）でHRVが増大する条件では、同一の欠損刺激に対する反射的反応開始が遅れ（Withhold時間が延長する）
- **supports**: D3（Withholdの身体的技法）, D2（欠損の身体的入り口＝内受容）, E07（身体は最初の問い）
- **4layer**: Layer 0→3。呼吸による内受容入力の調律が、Layer 3 のWithhold（保持）を回復/維持する経路を提供する
- **bspl**: PL収益（休息収益＝呼吸による自律神経調律）
- **refs**:
  - Zaccaro, A., Piarulli, A., Laurino, M., Garbella, E., Menicucci, D., Neri, B., & Gemignani, A. (2018). How Breath-Control Can Change Your Life: A Systematic Review on Psycho-Physiological Correlates of Slow Breathing. *Front Hum Neurosci*, 12, 353.
  - Bernardi, L., et al. (2002). Slow breathing increases arterial baroreflex sensitivity in patients with chronic heart failure. *Circulation*, 105(2), 143-145.
  - Joseph, C. N., et al. (2005). Slow breathing improves arterial baroreflex sensitivity and decreases blood pressure in essential hypertension. *Hypertension*, 46(4), 714-718.
  - Lehrer, P. M., et al. (2003). Heart rate variability biofeedback increases baroreflex gain and peak expiratory flow. *Psychosom Med*, 65(5), 796-805.
  - Lehrer, P. M., Sasaki, Y., & Saito, Y. (1999). Zazen and cardiac variability. *Psychosom Med*, 61(6), 812-821.
- **used_in**: ISS-37（BSPL深掘り）, LOG-20260206-002
- **notes**: HRV指標（特にLF成分）は呼吸周波数の影響を強く受け、単純に「交感/副交感の強さ」と同一視できない。介入研究はサンプルサイズやデバイス差が大きく、疾患群/健常群で効果量が変動するため、一般化は慎重に行う。

---

## EV-LS-011: 神経効率仮説

- **layer**: [P+M+S]
- **sub_field**: LS-B
- **claims**:
  - [P] 神経効率仮説は、同等の課題成績を達成する際に高知能群ほど脳活動（例: PETの糖代謝、fMRIのBOLD反応）が低い傾向を示すという観察に基づく
  - [P] PET研究で、推論課題遂行中の脳局所グルコース代謝率が知能指標と負の相関を示すことが報告されている
  - [P] 学習に伴い課題関連領域のグルコース代謝が低下することが報告され、課題の熟達が代謝コスト低下と関連する可能性が示唆されている
  - [P] レビューでは、神経効率の観察は課題種・難易度・被験者特性（性差など）で条件依存に変化しうることが整理されている
  - [M] 神経効率はBSPLの『営業利益（運転効率）』として読める——同じ成果を得るための費用（入力/保持/切替）が下がるほど、Withholdに回せる余力が増える
  - [M] 学習に伴う代謝コスト低下は、Withholdの長期的成果が『費用構造の改善』として蓄積する像を与える——問いを保持できる時間は、学習により拡張しうる
  - [S] 同一課題を反復学習した個人内で、課題中の代謝指標の低下が大きいほど、Withhold課題における保持時間が延長する
- **supports**: D3（Withholdの熟達的形態）, E06（すぐに解決しないことを可能にする余力）
- **4layer**: Layer 1-3 横断。予測精度の向上（Layer 1）により必要活動が減り、Layer 3 のWithhold余力が増える
- **bspl**: 営業利益（運転効率）、PL費用（保持コストの低下）
- **refs**:
  - Neubauer, A. C., & Fink, A. (2009). Intelligence and neural efficiency. *Neurosci Biobehav Rev*, 33(7), 1004-1023.
  - Haier, R. J., et al. (1988). Cortical glucose metabolic rate correlates of abstract reasoning and attention studied with positron emission tomography. *Intelligence*, 12(2), 199-217.
  - Haier, R. J., et al. (1992). Intelligence and changes in regional cerebral glucose metabolic rate following learning. *Intelligence*, 16(3-4), 415-426.
- **used_in**: ISS-37（BSPL深掘り）, LOG-20260206-002
- **notes**: 「低活動＝高効率」は常に成り立つわけではなく、課題難易度が高い条件では高知能群で活動増加が見られる報告もある。代謝/活動指標は血管反応・戦略差・動機づけなどの交絡を受けるため、因果推論や個人差解釈には注意が必要。

---

## クロスリファレンス

### D1-D4 との対応

| 定義 | 主要論拠 |
|------|---------| 
| D1（欠損駆動思考） | EV-LS-002（遅い統合＝問いとして拾う時間的基盤）, EV-LS-008（代謝予算による選別圧）, EV-LS-009（差分が立ち上がる入口） |
| D2（欠損） | EV-LS-001（保持のエネルギーコスト）, EV-LS-006（蓄積コスト）, EV-LS-007（代謝的清算）, EV-LS-008（保持コストの底板）, EV-LS-009（差分の生化学的フック） |
| D3（Withhold） | EV-LS-001（代謝的前提）, EV-LS-003（物理的上限）, EV-LS-004（阻害要因）, EV-LS-005（長期的成果）, EV-LS-006（失敗モード）, EV-LS-007（回復条件）, EV-LS-008（コスト構造）, EV-LS-010（身体的技法）, EV-LS-011（熟達的形態） |
| D4（情動の構成） | 間接的（EV-LS-004: 炎症による情動調節障害） |

### BSPLモデルとの対応

| BSPL項目 | 主要論拠 |
|---------|---------| 
| BS資産: 代謝バッファ | EV-LS-001（グリコーゲン/乳酸） |
| BS資産: ミトコンドリア能力 | EV-LS-003（mtCB1） |
| BS資産: 可塑性資本 | EV-LS-005（ミエリン化） |
| BS負債: 未処理ストレス | EV-LS-006（アロスタティック負荷） |
| BS負債: 炎症 | EV-LS-004（ミクログリア） |
| BS負債: 睡眠負債 | EV-LS-007（グリンパティック系） |
| PL中央: mtCB1予算ノブ | EV-LS-003（mtCB1） |
| PL収益: 学習収益 | EV-LS-001（LTP維持）, EV-LS-005（ミエリン蓄積） |
| PL収益: 休息収益 | EV-LS-007（グリンパティック排出）, EV-LS-010（呼吸による自律神経調律） |
| PL費用: 入力コスト | EV-LS-008（信号伝達のATPコスト） |
| PL費用: 保持コスト | EV-LS-008（状態維持の代謝支出） |
| PL費用: 切替コスト | EV-LS-009（予測モデル更新のドーパミン系コスト） |
| 営業利益: 運転効率 | EV-LS-011（神経効率） |

### 他ドメインとの接点

| 接続先 | 接続するEV-LS | 接続の性質 |
|--------|-------------|-----------|
| EV-NS-001（予測符号化） | EV-LS-002 | precision調整の代謝的基盤 |
| EV-NS-001（予測符号化） | EV-LS-009 | 予測誤差（差分）の神経化学的フック（LS） |
| EV-NS-002（内受容感覚） | EV-LS-010 | 呼吸による内受容入力の調律（LS） |
| EV-NS-004（実行機能） | EV-LS-001, EV-LS-003 | Withholdの神経基盤（NS）と代謝基盤（LS） |
| EV-NS-007（ポリヴェーガル） | EV-LS-006 | 自律神経調節とアロスタシスの接点 |
| EV-PA（Container-Contained） | EV-LS-001 | [M] アストロサイト＝生物学的Container |
| CN-001（内在化された関係） | EV-LS-005 | [M] ミエリン化＝関係の内在化の物理的基盤 |
