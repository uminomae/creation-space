# briefing-10c-uncertain-resolution.md

**タスク名**: TASK #10c — Withhold観測指標の[UNCERTAIN]精度上げ
**Type**: C（Creative analysis + Evidence-driven refinement）
**出力先**: `inbox/deepdive/REPORT-withhold-uncertain-resolution.md`
**作成日**: 2026-02-07
**起点**: `inbox/deepdive/REPORT-withhold-observability.md` §D.3（[UNCERTAIN]残量レポート）
**依存**: なし（先行タスク）

---

## 0. Source Repository

**リポジトリ**: `uminomae/kesson-driven-thinking`（GitHub, Private）

**作業開始前に、リポジトリ全体のファイル構造を確認し、以下の必読ファイルを全て読み込んでからタスクに着手せよ。**

### 必読ファイル

| 優先度 | パス | 読む理由 |
|--------|------|----------|
| ★★★ | `inbox/deepdive/REPORT-withhold-observability.md` | 本タスクの入力。§D.3の3件の[UNCERTAIN]が対象 |
| ★★★ | `inbox/deepdive/REPORT-withhold-structuring.md` | 7段階スペクトラムの定義。§Aが各段階の原典 |
| ★★★ | `base/schema/core-definitions.md` | D1-D4定義。特にD3, D3-a |
| ★★ | `base/text/m1-consciousness-os/part-5-withhold.md` | Layer 3の現行記述。成立条件表あり |
| ★★ | `base/evidence/evidence-neuroscience.md` | EV-NS-004, EV-NS-007。身体兆候・誤差検出の根拠 |
| ★★ | `base/evidence/evidence-psychoanalysis.md` | EV-PA-002, EV-PA-003, EV-PA-010。境界・解離 |
| ★★ | `base/evidence/evidence-business-org.md` | EV-BZ-009, EV-BZ-010。対話保留・コンピテンシートラップ |
| ★★ | `base/evidence/evidence-developmental-psychology.md` | EV-DP-002, EV-DP-004。内在化・実行機能 |
| ★ | `base/evidence/evidence-creativity.md` | EV-CR-017, EV-CR-018。外部化・発散収束 |
| ★ | `base/evidence/evidence-life-sciences.md` | EV-LS-006。睡眠・回復 |

---

## 1. Context（タスクの背景）

REPORT-withhold-observability.md は7段階×4観点の観測指標を定義し、総合評価Highを得た。
しかし§D.3に**意図的に残した[UNCERTAIN]が3件**ある。本タスクはこれを1件ずつ精査し、解消または「解消不可の理由」を明文化する。

### 対象[UNCERTAIN]（3件）

| # | 内容 | 現状の問題 | 関連Evidence |
|---|------|-----------|-------------|
| U-1 | 段階3の身体的兆候 | 「段階2ほど緊張が見えない」のみ。識別力が弱い | EV-NS-007 |
| U-2 | 段階4の「更新が起きていない」の外部観測指標 | 反復と更新の差分を外部からどう見分けるか | EV-BZ-010 |
| U-3 | 段階5↔6の内在化判定（支援撤去の適切タイミング） | いつ外的Containerを弱めてよいか | EV-DP-002 |

---

## 2. Scope（作業範囲）

3件それぞれについて、以下の4ステップで精査せよ。

### ステップ1: Evidence再走査

リポジトリ内の全evidence DBを横断し、当該[UNCERTAIN]に関連する追加の論拠を収集する。既にREPORT-withhold-observability.mdで参照されたEV-IDに加え、**未参照のEV-IDがないか**確認する。

### ステップ2: 追加指標の提案

収集したEvidenceに基づき、以下を追加提案する：
- **追加の観測項目**（言語的/行動的/身体的/内省的）
- **追加の判定質問**（自己報告型/外部観測型）
- **追加の誤判定パターン**

### ステップ3: 解消度の自己評価

各[UNCERTAIN]について、以下の3段階で自己評価する：

| 評価 | 意味 |
|------|------|
| **RESOLVED** | 追加指標により実用的な識別が可能になった |
| **REDUCED** | 識別力は向上したが、完全な解消ではない。残る曖昧さを明記 |
| **UNRESOLVABLE** | 現在のEvidence水準では解消不可能。理由を明記 |

### ステップ4: REPORT-withhold-observability.mdへの差分提案

§A/§B/§Cのどの箇所にどの追加指標を挿入すべきか、具体的なセクション番号と挿入位置を指定する。

---

### U-1詳細: 段階3の身体的兆候

**現状**: §A.3の身体的兆候は「段階2ほどの高い緊張は見えないが、落ち着きのなさ（急かし）が残る」の1文のみ。

**探索方向**:
- 段階2（闘争逃避）と段階3（早期収束）の自律神経状態の違い（EV-NS-007をさらに精査）
- 「急かし」の身体的表出: 姿勢の前傾、視線の遊び、手の動き、呼吸のリズム変化
- 段階3固有の兆候はあるか、それとも「段階2の緩和版」としか記述できないか（後者なら[UNRESOLVABLE]の候補）

---

### U-2詳細: 段階4の「更新なし」の外部観測

**現状**: §A.4は「情報収集が同じ場所を回り続ける（モデル更新が見えない）」だが、外部からの観測方法が具体的でない。

**探索方向**:
- **反復と更新の差分を外部から見分ける指標**:
  - 対話中の語彙の変化（同じ説明 vs 言い換え/新しい概念の登場）
  - 質問への応答パターン（「それはもう考えた」vs「あ、そういう角度は…」）
  - 外部化物の変化（メモ/図が更新されるか、同じものを書き直すか）
- EV-BZ-010（コンピテンシー・トラップ）の「探索停止」の行動的指標
- 時間軸: 何回の対話/何日経過で「更新なし」と判断できるか

---

### U-3詳細: 段階5↔6の内在化判定

**現状**: §B.5は「支援者が介入を弱めても、相手が段階2へ急落しないか」だが、撤去のタイミング判断が具体的でない。

**探索方向**:
- **内在化の兆候**:
  - 「相手がいない時間にも保持が続いた」経験の自己報告（EV-DP-002）
  - 外部化（メモ/独り言/行動変化）が支援者不在時にも起きるか
  - 別の関係でも保持が成立するか（特定人物への固定度）
- **段階的撤去のプロトコル候補**:
  - Bowlbyの安全基地「離れてまた戻る」パターン（EV-DP-002）
  - Winnicottのgood-enough: 完全撤去ではなく「少しだけ足りない」状態の設計
  - 臨床における治療終結の判断基準（参照可能なEvidenceがあれば）
- **誤判定防止**: 「一時的な安定」と「内在化された安定」の区別

---

## 3. Vocabulary Constraints（用語制約）

### 必ず使う用語

| 用語 | 意味 | 注意 |
|------|------|------|
| D1-D4 | コア定義 | 番号を間違えない |
| Layer 0-3 | 4層モデル | 必ず番号付き |
| F軸, O軸 | 恐れ/生存 と 愛/関係 | 混同しない |
| Withhold | 保持機能（大文字W） | "withholding"とは書かない |
| Container | 他者がWithholdを支える機能（大文字C） | |
| 段階1-7 | TASK #10で定義した名称を正確に使う | 名称ブレ防止 |

### 使ってはいけない用語

| 禁止 | 理由 | 代替 |
|------|------|------|
| 「証明する」 | 仮説段階 | 「構造的に対応する」「〜として読める」 |
| 「正常/異常」 | 二値的判断の回避 | スペクトラム上の位置として記述 |
| 「この人は段階X」 | 人のラベル化 | 「この文脈では段階Xの兆候が見られる」 |
| 「必然的に」 | 観測指標は相関であり因果ではない | 「〜の示唆がある」 |

---

## 4. Safety Valves（安全弁）

| タグ | 使用場面 |
|------|---------|
| `[UNCERTAIN]` | 精査後も境界が曖昧な箇所（減らすことが目的だが、残るなら残す） |
| `[SPECULATIVE]` | Evidence不足で推定に基づく箇所 |
| `[SELF-REPORT_BIAS]` | 自己報告の信頼性が低い指標 |
| `[CONTEXT_DEPENDENT]` | 文脈で変動しやすい指標 |
| `[RESOLVED]` | 本タスクで解消できた[UNCERTAIN]に付与（新規タグ） |
| `[REDUCED]` | 識別力は向上したが完全解消でない箇所に付与（新規タグ） |
| `[UNRESOLVABLE]` | 現Evidence水準で解消不可能と判断した箇所に付与（新規タグ） |

**重要**: 解消できないものを無理に解消するな。`[UNRESOLVABLE]`と書くほうが、こじつけた指標を追加するより価値が高い。

---

## 5. Completion Criteria（完了条件）

| # | 条件 | 確認方法 |
|---|------|---------|
| 1 | U-1, U-2, U-3の3件全てに対してステップ1-4が実行されている | 各セクションの存在確認 |
| 2 | 各件にEvidence再走査の結果（新規EV-ID or 「追加なし」）が記載 | §内を確認 |
| 3 | 各件に追加指標が最低2つ提案されている（[UNRESOLVABLE]を除く） | 提案数を数える |
| 4 | 各件に解消度の自己評価（RESOLVED/REDUCED/UNRESOLVABLE）がある | 自己評価セクション確認 |
| 5 | REPORT-withhold-observability.mdへの差分提案（セクション番号＋挿入位置）がある | §差分提案を確認 |
| 6 | Safety Valveタグが適切に使用されている | 全体スキャン |
| 7 | 禁止用語が含まれていない | 全体スキャン |

---

## 6. Output Format（出力形式）

```markdown
# REPORT: Withhold観測指標の[UNCERTAIN]精度上げ

- タスク名: TASK #10c — [UNCERTAIN]精度上げ
- Type: C
- 作成日: YYYY-MM-DD
- 起点: REPORT-withhold-observability.md §D.3
- 出力先: inbox/deepdive/REPORT-withhold-uncertain-resolution.md

---

## 0. イントロ（目的・前提）

## 1. U-1: 段階3の身体的兆候
### 1.1 Evidence再走査
### 1.2 追加指標の提案
### 1.3 解消度の自己評価
### 1.4 差分提案

## 2. U-2: 段階4の「更新なし」の外部観測
### 2.1 Evidence再走査
### 2.2 追加指標の提案
### 2.3 解消度の自己評価
### 2.4 差分提案

## 3. U-3: 段階5↔6の内在化判定
### 3.1 Evidence再走査
### 3.2 追加指標の提案
### 3.3 解消度の自己評価
### 3.4 差分提案

## 4. 統合サマリー
| # | 対象 | 解消度 | 追加指標数 | 残る曖昧さ |
|---|------|--------|-----------|-----------|

## 付録: 本レポートが参照した主要ファイル
```

---

## 7. Output Location

```
inbox/deepdive/REPORT-withhold-uncertain-resolution.md
```

---

## 8. 注意事項

- 本タスクは「穴を埋める」仕事であって「新しい構造を作る」仕事ではない。REPORT-withhold-observability.mdの構造を壊さないこと
- Evidenceの新規追加ではなく、**既存Evidence DBの再走査**が主。リポジトリ外の文献を新たに持ち込む必要はない
- U-1（身体兆候）は最も解消が難しい可能性がある。[UNRESOLVABLE]になっても構わない
- U-2（更新なし）は対話場面の具体的な行動指標に落とし込むことが鍵
- U-3（内在化判定）は実践的な「段階的撤去プロトコル」の萌芽になりうるが、本タスクでは指標の精度上げに留め、プロトコル設計には踏み込まない
- **TASK #10dの入力になる**: 本タスクの成果はTASK #10d（Container対応表）とTASK #10f（ケースブック）で参照される
