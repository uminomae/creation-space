# briefing-10f-matching-recalibration.md

**タスク名**: TASK #10f — 有向7×7マッチング表の観測指標付き再校正
**Type**: C（Creative analysis + Structure augmentation）
**出力先**: `inbox/deepdive/REPORT-matching-recalibration.md`
**作成日**: 2026-02-07
**起点**: `inbox/deepdive/REPORT-withhold-structuring.md`（§B 有向7×7マッチング表）
**依存**: TASK #10c（[UNCERTAIN]精度上げ）の結果があれば参照。なければ現行版で進行

---

## 0. Source Repository

**リポジトリ**: `uminomae/kesson-driven-thinking`（GitHub, Private）

**作業開始前に、リポジトリ全体のファイル構造を確認し、以下の必読ファイルを全て読み込んでからタスクに着手せよ。**

### 必読ファイル

| 優先度 | パス | 読む理由 |
|--------|------|----------|
| ★★★ | `inbox/deepdive/REPORT-withhold-structuring.md` | §Bの有向7×7マッチング表が本タスクの入力。全49セルの原典 |
| ★★★ | `inbox/deepdive/REPORT-withhold-observability.md` | §A/§B/§Cの観測指標。各セルに接続する兆候 |
| ★★★ | `base/schema/core-definitions.md` | D1-D4, D3-a |
| ★★ | `base/text/m1-consciousness-os/part-5-withhold.md` | Layer 3記述 |
| ★★ | `base/evidence/evidence-psychoanalysis.md` | EV-PA-002, EV-PA-004, EV-PA-008。マッチングの精神分析的根拠 |
| ★★ | `base/evidence/evidence-developmental-psychology.md` | EV-DP-002, EV-DP-004。発達段階間の非対称性 |
| ★★ | `base/evidence/evidence-business-org.md` | EV-BZ-009, EV-BZ-013。組織的マッチング |
| ★ | `base/evidence/evidence-neuroscience.md` | EV-NS-004, EV-NS-007 |
| ★ | `base/evidence/evidence-creativity.md` | EV-CR-017 |
| ★ | `inbox/deepdive/REPORT-withhold-uncertain-resolution.md` | TASK #10cの出力。**存在すれば**参照 |

---

## 1. Context（タスクの背景）

REPORT-withhold-structuring.md §Bは有向7×7マッチング表を作成した。全49セルにEvidence参照と非対称性記述がある。

しかし現状の表は**理論的な予測**に留まっており、「このマッチングがうまくいっている/失敗している兆候」が観測レベルで記述されていない。

本タスクは、REPORT-withhold-observability.mdの観測指標を使い、各セルに**「うまくいく兆候」と「失敗する兆候」を最低1つずつ**追加し、表を"運用可能"にする。

### 工数への注意

49セル×2兆候 = 98項目の記述が必要。全セルを均等に深掘りすることは現実的でない。以下の優先順位で作業せよ：

| 優先度 | セル群 | 理由 |
|--------|--------|------|
| ★★★ | 隣接段階（差=1）: 7セル | H2（隣接衝突）の検証。最も紛らわしい |
| ★★★ | 2段階差（差=2）: 6セル | H2（2段調和）の検証。師弟関係の核心 |
| ★★ | 同段階（差=0）: 7セル | 同段階同士の共鳴/共倒れの識別 |
| ★ | 3段階差以上: 残りのセル | 概要レベルでよい |

---

## 2. Scope（作業範囲）

### §A: 優先セルの再校正（隣接＋2段階差＋同段階 = 20セル）

各セルに以下を追加する：

| フィールド | 内容 |
|-----------|------|
| **うまくいく兆候（成功指標）** | このマッチングが機能しているときに観測されるもの（1-3項目） |
| **失敗する兆候（失敗指標）** | このマッチングが機能不全のときに観測されるもの（1-3項目） |
| **観測の手がかり** | REPORT-withhold-observability.mdの判定質問IDまたは§Aの兆候への参照 |
| **Evidence** | EV-ID |
| **タグ** | Safety Valveタグ |

#### 出力形式（1セル分の例）

```markdown
### セル [3→5]: 早期収束 → 関係依存保持

**原典記述**（REPORT-withhold-structuring.md §Bより）:
> [原典のセル内容を引用]

**うまくいく兆候**:
1. 段階3の当事者が、段階5の支援者の「急がなくてよい」モデルを観察し、自分の収束パターンに気づく（L1-4: 問いの言い換え）`[SPECULATIVE]`
2. 段階5の支援者が、段階3の当事者の「決めてしまう」エネルギーに巻き込まれず保持を維持する（L3-7: 外的Withhold）`[CONTEXT_DEPENDENT]`

**失敗する兆候**:
1. 段階3の当事者が支援者の保持を「優柔不断」と判断し、さらに早期収束を加速する（L1-3: 同じ説明の反復 + 加速）
2. 段階5の支援者が段階3の「結論の速さ」に同調してしまい、共に閉じる（L3-2: 再評価の余地喪失）`[CONTEXT_DEPENDENT]`

**Evidence**: EV-BZ-010, EV-PA-002
```

### §B: 残りセルの概要記述（29セル）

3段階差以上のセルは、**うまくいく/失敗の兆候を各1文**で概要記述する。表形式でよい。

```markdown
| A→B | うまくいく兆候（1文） | 失敗する兆候（1文） | Evidence | タグ |
|------|---------------------|---------------------|----------|------|
| 1→4 | ... | ... | ... | ... |
```

### §C: マッチングパターンの横断分析

20セルの詳細記述を横断的に分析し、以下を記述する：

1. **H2の観測的検証**: 隣接段階（差=1）のセルで「衝突」の兆候は本当に多いか？ 2段階差のセルで「調和」の兆候は本当に多いか？
   - Evidenceに基づく結論、または`[SPECULATIVE]`での仮説
2. **非対称性のパターン**: A→BとB→Aで兆候が異なるケース。どの段階の組み合わせで非対称性が最も顕著か？
3. **「共倒れ」パターン**: 同段階同士（差=0）のセルで、保持が相互強化する場合と共倒れする場合の分岐条件

### §D: マッチング表v2（再校正済み統合表）

REPORT-withhold-structuring.md §Bの原典表に、§A/§Bの兆候を統合した**v2表**を出力する。形式は原典と同一（7×7マトリクス）で、各セルに成功指標/失敗指標を追記する。

---

## 3. Vocabulary Constraints（用語制約）

### 必ず使う用語

| 用語 | 意味 | 注意 |
|------|------|------|
| D1-D4 | コア定義 | |
| Layer 0-3 | 4層モデル | |
| Withhold, Container | 大文字 | |
| 段階1-7 | TASK #10の名称を正確に | |
| A→B表記 | マッチングの方向（AがContainer提供者、Bが受け手） | REPORT-withhold-structuring.mdの表記に従う |
| 判定質問ID（L0-1等） | REPORT-withhold-observability.md §Cの参照 | |

### 使ってはいけない用語

| 禁止 | 理由 | 代替 |
|------|------|------|
| 「相性」 | 人格特性のラベルに聞こえる | 「段階間のマッチング」 |
| 「必ず衝突する」 | H2は仮説段階 | 「衝突の兆候が出やすい」 |
| 「この段階の人」 | 人のラベル化 | 「この段階にいるとき」 |

---

## 4. Safety Valves（安全弁）

| タグ | 使用場面 |
|------|---------|
| `[UNCERTAIN]` | マッチングの成否予測が曖昧な場合 |
| `[SPECULATIVE]` | Evidence不足で推定に基づく兆候 |
| `[CONTEXT_DEPENDENT]` | 関係の質・場の安全度で兆候が変わる場合 |
| `[SCALE_JUMP]` | 個人間→チーム/組織のスケール移動時 |
| `[WEAK_MAPPING]` | 原典表のセル内容が薄い場合（兆候の追加が困難） |

**重要**:
- 49セル全てに充実した兆候を書く必要はない。Evidenceがないセルは`[WEAK_MAPPING]`で正直に書け
- H2（隣接衝突・2段調和）は**検証が目的の1つ**。データが仮説を支持しない場合は正直に報告せよ。仮説への忠誠より事実への忠誠
- 非対称性の記述（A→B ≠ B→A）は本タスクの付加価値。意識して書け

---

## 5. Completion Criteria（完了条件）

| # | 条件 | 確認方法 |
|---|------|---------|
| 1 | §A: 優先20セルに成功指標/失敗指標が各1つ以上ある | セル数×指標数確認 |
| 2 | §B: 残り29セルに概要記述（各1文）がある | 表の行数確認 |
| 3 | §C: H2の観測的検証が記述されている | セクション存在確認 |
| 4 | §C: 非対称性パターンの分析がある | セクション存在確認 |
| 5 | §D: v2統合表が7×7マトリクス形式で出力されている | 表の構造確認 |
| 6 | 観測の手がかりがREPORT-withhold-observability.mdの判定質問IDを参照している | ID参照確認 |
| 7 | Safety Valveタグが適切に使用されている | 全体スキャン |
| 8 | 禁止用語が含まれていない | 全体スキャン |

---

## 6. Output Format（出力形式）

```markdown
# REPORT: 有向7×7マッチング表の観測指標付き再校正

- タスク名: TASK #10f — マッチング表再校正
- Type: C
- 作成日: YYYY-MM-DD
- 起点: REPORT-withhold-structuring.md §B
- 出力先: inbox/deepdive/REPORT-matching-recalibration.md

---

## 0. イントロ（目的・前提・優先順位の説明）

# §A: 優先セルの再校正（20セル詳細）
## A.1 同段階（差=0）
### セル [1→1]
...
### セル [7→7]
## A.2 隣接段階（差=1）
### セル [1→2]
...
## A.3 2段階差（差=2）
### セル [1→3]
...

# §B: 残りセルの概要記述（29セル表形式）

# §C: マッチングパターンの横断分析
## C.1 H2の観測的検証
## C.2 非対称性のパターン
## C.3 「共倒れ」パターン

# §D: マッチング表v2（再校正済み統合表）

# §E: 統合と限界
## E.1 [UNCERTAIN]残量レポート
## E.2 H2仮説の現時点での支持度

## 付録: 本レポートが参照した主要ファイル
```

---

## 7. Output Location

```
inbox/deepdive/REPORT-matching-recalibration.md
```

---

## 8. 注意事項

- **工数が最大のタスク**。完璧を目指さず、優先20セルの品質を確保することに注力せよ
- 原典表（REPORT-withhold-structuring.md §B）の内容を**変更するな**。追記のみ
- H2仮説の検証は重要だが、データが支持しない場合は`[SPECULATIVE]`で正直に報告。pjdhiroの仮説を守ることよりEvidence整合性が優先
- TASK #10cの出力が存在すれば、特にU-2（段階4の更新なし指標）の追加指標がセル[4→X]群に直接使える
- §D（v2統合表）は**REPORT-withhold-structuring.md §Bの表を拡張した形式**で出力する。原典引用＋追記の形を取ること
